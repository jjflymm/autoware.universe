# diapp_cmake

This package provides CMake scripts for DiAPP.

## Usage

### diapp_package.cmake

Call `diapp_package()` before defining build targets, which will set common options for DiAPP.

```cmake
cmake_minimum_required(VERSION 3.5)
project(package_name)

find_package(diapp_cmake REQUIRED)
diapp_package()

ament_auto_add_library(...)
```
