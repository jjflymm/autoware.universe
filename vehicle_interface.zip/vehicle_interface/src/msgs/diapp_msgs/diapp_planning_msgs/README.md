# diapp_planning_msgs

## PoseWithUuidStamped.msg

The message contains a pose data attached with an uuid and header.
Use case example is [goal modification](https://github.com/orgs/autowarefoundation/discussions/2983)
