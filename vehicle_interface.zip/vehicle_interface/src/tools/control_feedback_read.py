#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Sep 13 13:39:24 2023
@author: du

Description:
    T018 车辆控制反馈 can 报文读取与解析
Steps:
    1. 读取 T018行泊一体控制交互协议_20230315_du.xlsx 为 df
    2. 在 len_i 列中，匹配输入的 can id，例如 "18FF9B91"
    3. 从匹配到 can id 的下一行开始，分别匹配 1.0 和 8.7，然后截取出这中间的区域 df_can
    4. 对 df_can 每一行进行索引
        4.1 range: 将 range 由 1.1 - 8.7 转换为 int 的 0 - 64，并取出当前行的 index 范围
        4.2 将当前行 index 范围内的 can 报文进行进制转换，二进制字符串表示形式：8.7 - 8.1, ..., 1.7 - 1.0
        4.3 def: 先匹配 PH 表达式，匹配的关键词是 'PH' 和 'INT'，匹配上则计算其表达式的值，计算时使用十进制值
        4.4 def: 若 PH 表达式未匹配上，则使用 16 进制对状态码进行匹配
Can id:
    1 0x18F60431 自动驾驶驱动、转向反馈报文
    2 0x18FF9B91 自动驾驶系统反馈报文1
    3 0x18F8CA2 自动驾驶系统反馈报文2
    4 0x18F8DA2 自动驾驶系统反馈报文3
    5 0x18F8EA2 自动驾驶系统反馈报文4
    6 0x18F0091B 自动驾驶加速度反馈报文
    7 0x18FEBF1B 自动驾驶车速反馈报文
    8 0x18F0011B 自动驾驶制动系统状态反馈报文
    9 0x08FE6E1B 自动驾驶轮速反馈报文
    10 0x18FE4147 自动驾驶辅控状态反馈报文
    11 0x18F6832F 线控VIN反馈
    12 0x18F6832F 线控VIN反馈
    13 0x18F6832F 线控VIN反馈
    14 0x18fef434 线控胎压监测报文
    15 0x18FEC1EF 线控总里程反馈
    16 0x18F8FA2 车重反馈报文
"""

import re
import os
import numpy as np
import pandas as pd


def range_str2num(s:str):
    """ 范围字符串转换为数字
    Notes:
        8.7 = (8 - 1) * 8 + 7
    """
    if '.' in s:
        s_split = s.split(".")
        x = int(s_split[0])
        y = int(s_split[1])
    elif 'nan' in s:
        x = 0
        y = 0
    else:
        # 尝试将整个字符串转换为整数
        try:
            x = int(s)
        except ValueError:
            # 如果转换失败，可能是因为字符串中包含非数字字符
            # 在这种情况下，我们可以假设起始位置是0，结束位置是0
            x = 0
            y = 0
        # x = int(s)
        # y = 0
    result = (x - 1) * 8 + y
    return result


def read_xlsx(path, sheet_name):
    # 读取 excel 文件
    df = pd.read_excel(path, sheet_name=sheet_name, dtype=str)
    cols_past = ["Unnamed: " + str(i)  for i in range(df.shape[1])]
    cols_new = cols_past.copy()
    cols_new[1] = "range"
    cols_new[2] = "len"  # can id
    cols_new[3] = "name"
    cols_new[4] = "def"
    cols_dict = {}
    for i in range(len(cols_past)):
        cols_dict[cols_past[i]] = cols_new[i]
    df.rename(columns=cols_dict, inplace=True)
    return df


def find_can_df(df, can_id):
    # 读取 df 中 can id 所在的行范围，并截取出来
    can_id_name = None
    can_id_begin, can_id_end = 0, 0
    find_can_id_flag = False
    for i in range(df.shape[0]):
        can_id_i = df.loc[i, "len"]
        range_i =df.loc[i, "range"]
        # find
        if isinstance(can_id_i, str) and can_id in can_id_i:
            # print(df.loc[i, "len"], type(df.loc[i, "len"]))
            find_can_id_flag = True
            can_id_name = df.loc[i, "name"]
        if find_can_id_flag and isinstance(range_i, str) and "1.0" in range_i and can_id_begin == 0:
            can_id_begin = i
        if find_can_id_flag and isinstance(range_i, str) and "8.7" in range_i and can_id_end == 0:
            can_id_end = i
    # print(f"--Find can id {can_id} between row: {can_id_begin} - {can_id_end}")
    # 截取该段
    df_can = df.loc[can_id_begin:can_id_end, :]
    df_can = df_can.reset_index(drop = True)
    return df_can, can_id_name


def extract_range_index(range_i:str):
    # 将 range 转换为 int 索引，例如 6.0-7.7 转换为 40 56
    if '-' in range_i:
        range_str = range_i.split("-")

        bits_begin = range_str2num(range_str[0])
        bits_end = range_str2num(range_str[1])
    else:
        bits_begin = range_str2num(range_i)
        bits_end = range_str2num(range_i)
    bits_end += 1
    # print(range_i, bits_begin, bits_end)
    # 为了防止 0 不可索引的情况，例如 can_data[-2:0] 不可索引，但是 can_data[-2:None] 可以
    # if bits_begin == 0:
    #     bits_begin = None
    return bits_begin, bits_end


def can_data_bin_trans(can_data_bin):
    """ 对 64 位的 can 二进制数据进行转换
    Notes:
        转换前："00000001 00000000 00010010 10001001 00011000 00001000 00000000 11100000"
        转换后："1110000000000000000010000001100010001001000100100000000000000001"
        相当于先翻转列表，再拼接
        如果需要索引 1.0-1.7，则使用：can_data[-7:]
        如果需要索引 8.0-8.7，则使用：can_data[-64:-56]
    """
    can_data_list = can_data_bin.split(" ")
    can_data_list = can_data_list[::-1]  # 翻转
    can_data = ""
    for i in can_data_list:
        can_data += i
    return can_data

def hex2bin(hex_string):
    """ 十六进制转换为二进制
    Notes:
        hex_string = '01 00 12 89 18 08 00 45' 转换为
        00000001 00000000 00010010 10001001 00011000 00001000 00000000 01000101
    """
    bin_string = ''

    # 将16进制字符串按照空格分割成一个列表
    hex_list = hex_string.split()

    # 遍历列表，将每个16进制数字转换为二进制
    for hex_num in hex_list:
        # 将16进制字符串转换为10进制整数
        decimal_num = int(hex_num, 16)
        # 使用bin()函数将10进制整数转换为二进制字符串，并去掉前缀'0b'
        binary_str = bin(decimal_num)[2:].zfill(8)
        # 输出二进制字符串
        bin_string = bin_string + binary_str + " "
    # print(bin_string[:-1])
    return bin_string[:-1]


def get_can_data_part(can_data_bin_reverse, range_i):
    # 将 range 转换为 int 索引，并取出该部分数据
    bits_begin, bits_end = extract_range_index(range_i)  # 将 range 转换为 int 索引，例如 6.0-7.7 转换为 40 56

    # 读取这部分所属信号的值，并转换为 16 进制。16 进制用于匹配状态，二进制用于计算 PH
    if bits_begin != 0:
        can_data_part2 = can_data_bin_reverse[-bits_end:-bits_begin]
    else:
        can_data_part2 = can_data_bin_reverse[-bits_end:]

    can_data_part10 = int(can_data_part2, 2)
    can_data_part16 = hex(can_data_part10)
    can_data_part16_upper = '0x' + can_data_part16[2:].upper()
    # print(can_data_part16)
    return can_data_part10, can_data_part16, can_data_part16_upper


def PH_expression_match(def_i, can_data_part10):
    # 1 表达式匹配：[PH=INT*4 Kpa/bit，offset：0] 匹配为 INT*4，返回当前值解析的 signal_value_str 字符串
    def_i_split = def_i.split('\n')  # 将字符串按行拆分成列表
    for line in def_i_split:
        if "PH" in line and "INT" in line:
            # print(line)
            pattern = r"[^INT+\-*/\d.]"
            PH_expression = re.sub(pattern, "", line)
            # 去除 km/h 留下的 /
            if PH_expression[-1] == "/":
                PH_expression = PH_expression[:-1]
            # print(line, "------", PH_expression)
            INT = can_data_part10
            try:
                PH_result = round(eval(PH_expression), 4)
            except Exception as e:
                print(def_i, can_data_part10)
                print(e)
                return ""
            signal_value_str = PH_expression.replace("INT", str(INT)) + " = " + str(PH_result)
    return signal_value_str


def hex_state_code_match(def_i, can_data_part16, can_data_part16_upper):
    # 2 十六进制状态码匹配：0x8，返回当前值解析的 signal_value_str 字符串
    def_i_split = def_i.split('\n')  # 将字符串按行拆分成列表
    for line in def_i_split:
        if can_data_part16 in line or can_data_part16_upper in line:
            signal_value_str = line
            break
    return signal_value_str


def control_feedback_read_core(
        can_id, can_data_hex, time_str="",
        print_can_msg=False,
        protocol_file_path="",
        sheet_name="线控车辆域控制器DBWDC发送",
        save_flag=False,
        can_id_protocol_dict={},
):
    """ 控制反馈 can 报文读取解析核心实现
    """
    result_str = ""
    # 18FF9B91 18F8CA2
    can_data_bin = hex2bin(can_data_hex)

    can_data_bin_reverse = can_data_bin_trans(can_data_bin)

    # 读取协议表数据
    if protocol_file_path == "":
        current_dir = os.path.dirname(os.path.abspath(__file__))
        protocol_file_path = os.path.join(current_dir, "S12N01ChassisStatusProtocol.xlsx")
        #protocol_file_path = os.path.join(current_dir, "T018ChassisProtocol.xlsx")
    if can_id in can_id_protocol_dict and can_id_protocol_dict[can_id] is None:
        return result_str, can_id_protocol_dict
    if can_id in can_id_protocol_dict and can_id_protocol_dict[can_id] is not None:
        # print("can_id in can_id_protocol_dict")
        df_can, can_id_name = can_id_protocol_dict[can_id]
    elif not os.path.exists(protocol_file_path):
        print(f"--No such file: {protocol_file_path}")
        return result_str, can_id_protocol_dict
    else:
        df = read_xlsx(protocol_file_path, sheet_name)  # 读取 excel 文件
        df_can, can_id_name = find_can_df(df, can_id)  # 读取 df 中 can id 所在的行范围，并截取出来
        can_id_protocol_dict[can_id] = [df_can, can_id_name]
    if can_id_name is None:
        can_id_protocol_dict[can_id] = None
        return result_str, can_id_protocol_dict
    result_str = f"\n--{time_str} Can ID: 0x{can_id}, {can_id_name}"
    # result_str += f"\nhex:[{can_data_hex}] \nbin:[{can_data_bin}] \nbin reverse:[{can_data_bin_reverse}]"
    result_str += f"\n--Hex:[{can_data_hex.upper()}]"
    result_str += "\n--{:3s}: {:10s} {:10s}\t {}".format("数据域", "当前值", "信号名称", "当前值解析")
    if print_can_msg:
        print(result_str)

    # %% test
    # count = 0
    # for i in range(df.shape[0]):
    #     len_i = df.loc[i, "len"]
    #     name_i = df.loc[i, "name"]
    #     if isinstance(len_i, str) and '0x' in len_i:
    #         count += 1
    #         print(count, len_i, name_i)
    # 1/0
    # %% 对照协议解析报文
    # 对 df_can 的每一行进行解析
    for i in range(df_can.shape[0]):
        # 转换 range 索引
        range_i = df_can.loc[i, "range"]
        range_i = str(range_i)
        # 将 range 转换为 int 索引，并取出该部分数据
        can_data_part10, can_data_part16, can_data_part16_upper = get_can_data_part(can_data_bin_reverse, range_i)


        # %% 读取信号值及定义，解析当前行的信号值
        def_i = str(df_can.loc[i, "def"])
        name_i = str(df_can.loc[i, "name"])
        signal_value_str = "x Unmatched!"

        # 1 表达式匹配：[PH=INT*4 Kpa/bit，offset：0] 匹配为 INT*4
        if not isinstance(def_i, str):
            pass
        elif "PH" in def_i and "INT" in def_i:
            signal_value_str = PH_expression_match(def_i, can_data_part10)
        # 2 状态码匹配：0x8
        elif can_data_part16 in def_i or can_data_part16_upper in def_i:
            signal_value_str = hex_state_code_match(def_i, can_data_part16, can_data_part16_upper)
        signal_str = "\n  {:7s}: {:10s} {:10s}\t {}".format(range_i, can_data_part16_upper, name_i, signal_value_str)
        result_str += signal_str
        if print_can_msg:
            print(signal_str[2:])  # 去除回车
    return result_str, can_id_protocol_dict


# %% main
if __name__ == "__main__":
    can_id="18F60431"
    can_data_hex = "7D   6A   3D   00   81   7D   00   00"

    can_id="18FF9B91"
    can_data_hex = "01   00   12   89   18   08   00   00"
    control_feedback_read_core(can_id, can_data_hex, print_can_msg=True)


