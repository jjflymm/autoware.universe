#!/bin/bash
# 一些常用工具的 bash 函数

# ------------------------------------- public -------------------------------------

# 配置 vcan 并模拟底盘发送 can 数据
can_msg_send () {
  sudo modprobe vcan && sudo ip link add can1 type vcan && sudo ip link set up can1
  python3 ~/DiAPP/tools/ros_tools/can_tools.py -i can1 -f 50 -c -1 -F ~/DiAPP/tools/ros_tools/test.txt
}
export -f can_msg_send

can_msg_gedit () {
  gedit ~/DiAPP/tools/ros_tools/test.txt
}
export -f can_msg_gedit

# can analysis
can_analysis () {
    filename="$1"
    extension="${filename##*.}"
    # 根据是否带有 .log 尾缀来自动选择是解析 can id 还是解析 candump 采集的 log 文件
    if [ "$extension" = "log" ]; then
        # 解析 log 文件
        echo "--Input candump log file: ${filename}, analyzing..."
        python3 ~/vehicle_interface/src/tools/can_analysis.py -F 1 -s 1 -i $1
    else
        echo "--Input can ID: ${filename}, analyzing..."
        # 实时解析 can ID 报文
        python3 ~/vehicle_interface/src/tools/can_analysis.py -I llcecan6 -s 0 -F 0 -c $1
    fi
}
export -f can_analysis

# colcon
colcon_build () {
  colcon build --symlink-install --cmake-args -DCMAKE_BUILD_TYPE=Release --base-path diapp --continue-on-error --packages-select $@
}
export -f colcon_build

colcon_rm () {
  for package in "$@"; do
    echo "rm -rf build/$package install/$package"
    rm -rf build/"$package"
    rm -rf install/"$package"
  done
}
export -f colcon_rm

colcon_rebuild () {
  colcon_rm $@
  colcon_build $@
}
export -f colcon_rebuild

# ros2 topic echo
topic_echo () {
  ros2 topic echo $1
}
export -f topic_echo

# ros2 topic list | grep
topic_list () {
  if [ -n "$1" ]; then
    ros2 topic list | grep $1
  else
    ros2 topic list
  fi
}
export -f topic_list

# topic type
topic_show_interface () {
  topic_type=$(ros2 topic info $1 | grep "Type:" | awk '{print $2}')
  echo "--Topic: $1"
  echo "--Type: $topic_type"
  ros2 interface show $topic_type
}
export -f topic_show_interface

topic_info () {
  ros2 topic info -v $1
}
export -f topic_info

# node list
node_list () {
  if [ -n "$1" ]; then
    ros2 node list | grep $1
  else
    ros2 node list
  fi
}
export -f node_list

