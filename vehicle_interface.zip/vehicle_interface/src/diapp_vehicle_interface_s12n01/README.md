# 20231221 diapp_vehicle_interface

[toc]

## 各层作用

1. **raw_vehicle_converter**：订阅规划给出的 control_cmd 的横纵向期望加速度和速度，然后根据标定表，插值得到给底盘的扭矩/踏板深度及方向盘扭矩。
2. **diapp_pacmod_interface**：订阅上层的 actuation_cmd，将该命令转换为自驾指令、档位指令、扭矩指令、制动指令、转向指令、灯控指令等。
3. **diapp_pacmod3**：（1）订阅上层的各种指令，将指令编码为底盘能识别的 can 消息话题；（2）解析 diapp_t018_can_rx_tx 层收到的底盘 can 报文反馈，然后将 report 消息发送给上层。
4. **diapp_t018_can_rx_tx**：（2）订阅上层的 can 消息话题，发送给底盘；（2）接收底盘 can 报文反馈，发送给上层做解析。**注：diapp_t018_can_rx_tx 只用作 can 数据的收发，不对 can 数据做的任何编码和解析！**编码和解析全部由 pacmod3 层完成。



## 如何根据 can id 新建一个 rpt

**以 T018ActStrRpt 为例：**

1. 在 `diapp_pacmod3_msgs/msg` 中创建 T018ActStrRpt.msg

   ```yaml
   # Measured vehicle speed as reported by vehicle

   std_msgs/Header header

   bool enabled
   float64 steering_angle      # T018 steering angle status
   ```

2. 在 `diapp_pacmod3_msgs/CMakeLists.txt` 的 SET 中添加   `"T018ActStrRpt.msg"`

3. 在用到该 msg 的地方添加头文件，如 `diapp_pacmod3/include/pacmod3_common.hpp` 和 `diapp_pacmod_interface/include/pacmod_interface.hpp`

   ```cpp
   // 需要将驼峰命名法修改为下划线
   #include <diapp_pacmod3_msgs/msg/t018_act_str_rpt.hpp>

   ```

4. 下面在 diapp_pacmod3 包中进行修改

5. 在 `pacmod3_core.hpp` 中定义类

   ```cpp
     class T018ActStrRptMsg
         : public Pacmod3TxMsg
     {
     public:
       static constexpr uint32_t CAN_ID = TMP_STEER_TORQUE_RPT_CAN_ID;

       bool enabled;
       float steering_angle;

       void parse(const std::vector<uint8_t> &in);
     };
   ```

6. 在 `pacmod3_core.cpp` 中

   ```cpp
   // 定义该 can id 的解析函数
     void T018ActStrRptMsg::parse(const std::vector<uint8_t> &in)
     {
       enabled = true;

       // 计算方向盘扭矩
       int16_t steering_angle_tmp = (static_cast<uint16_t>(in[2]) << 8) | in[1]; // 第 1 位和第 2 位是方向盘转角
       steering_angle_tmp = static_cast<double>(steering_angle_tmp * 0.1 - 1575.0);
       steering_angle = steering_angle_tmp * 0.0175; // 0.0175 将角度转换为弧度
     }
   // 在 make_message 中添加一个 case
       case T018ActStrRptMsg::CAN_ID:
         return std::shared_ptr<Pacmod3TxMsg>(new T018ActStrRptMsg);
         break;
   ```

7. 在 `pacmod3_node.cpp` 中

   ```cpp
   // 在 on_configure 函数中创建发布者
       can_pubs_[T018ActStrRptMsg::CAN_ID] =
           this->create_publisher<diapp_pacmod3_msgs::msg::T018ActStrRpt>("act_str_rpt", 20);
   // 在 callback_can_tx 函数中创建 解析器
         else if (msg->id == T018ActStrRptMsg::CAN_ID)
         {
           parser_class->parse(data_copy);
         }
   ```

8. 在`pacmod3_ros_msg_handler.cpp` 中

   ```cpp
   // 在 fillAndPublish 函数中添加
       else if (can_id == T018ActStrRptMsg::CAN_ID)
       {
         diapp_pacmod3_msgs::msg::T018ActStrRpt new_msg;
         auto dc_pub = std::dynamic_pointer_cast<
             lc::LifecyclePublisher<diapp_pacmod3_msgs::msg::T018ActStrRpt>>(pub);

         fillT018ActStrRpt(parser_class, &new_msg, frame_id);
         dc_pub->publish(new_msg);
       }

   // 然后创建函数 fillT018ActStrRpt
     void Pacmod3TxRosMsgHandler::fillT018ActStrRpt(
         const std::shared_ptr<Pacmod3TxMsg> &parser_class,
         diapp_pacmod3_msgs::msg::T018ActStrRpt *const new_msg,
         const std::string &frame_id)
     {
       auto dc_parser = std::dynamic_pointer_cast<T018ActStrRptMsg>(parser_class);

       new_msg->enabled = dc_parser->enabled;
       new_msg->steering_angle = dc_parser->steering_angle;

       new_msg->header.frame_id = frame_id;
       new_msg->header.stamp = rclcpp::Clock().now();
     }
   ```

9. 在`pacmod3_ros_msg_handler.hpp` 中声明 fillT018ActStrRpt

   ```shell
       void fillT018ActStrRpt(
           const std::shared_ptr<Pacmod3TxMsg> &parser_class,
           diapp_pacmod3_msgs::msg::T018ActStrRpt *const new_msg,
           const std::string &frame_id);
   ```

10. 下面在 diapp_pacmod_interface 包中进行修改

11. 在 `pacmod_interface.cpp `中

    ```cpp
    // 创建订阅者
      act_str_rpt_sub_ = std::make_unique<message_filters::Subscriber<diapp_pacmod3_msgs::msg::T018ActStrRpt>>(
          this, "/pacmod/act_str_rpt");

    ```

12. 在 `pacmod_interface.hpp `中

    ```cpp
        typedef message_filters::sync_policies::ApproximateTime<
          diapp_pacmod3_msgs::msg::VehicleSpeedRpt,
          diapp_pacmod3_msgs::msg::T018ActStrRpt,
          diapp_pacmod3_msgs::msg::SystemRptInt,
          diapp_pacmod3_msgs::msg::GlobalRpt,
          diapp_pacmod3_msgs::msg::T018BrkSysRpt,
          diapp_pacmod3_msgs::msg::SystemRptFloat>
          T018PacmodFeedbacksSyncPolicy;

    	std::unique_ptr<message_filters::Subscriber<diapp_pacmod3_msgs::msg::T018ActStrRpt>> act_str_rpt_sub_;
      	diapp_pacmod3_msgs::msg::T018ActStrRpt::ConstSharedPtr act_str_rpt_ptr_;    // [rad]

      void callbackPacmodRptT018(
          const diapp_pacmod3_msgs::msg::VehicleSpeedRpt::ConstSharedPtr vehicle_speed_rpt,
          const diapp_pacmod3_msgs::msg::SystemRptFloat::T018ActStrRpt act_str_rpt,
          const diapp_pacmod3_msgs::msg::SystemRptInt::ConstSharedPtr shift_rpt,
          const diapp_pacmod3_msgs::msg::GlobalRpt::ConstSharedPtr global_rpt,
          const diapp_pacmod3_msgs::msg::T018BrkSysRpt::ConstSharedPtr brksys_rpt,
          const diapp_pacmod3_msgs::msg::SystemRptFloat::ConstSharedPtr steer_torque_rpt);
    ```

