// Copyright (c) 2019 AutonomouStuff, LLC
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.

#ifndef PACMOD3__PACMOD3_CORE_HPP_
#define PACMOD3__PACMOD3_CORE_HPP_

#include <cstring>
#include <sstream>
#include <cstdint>
#include <memory>
#include <vector>
#include <string>

#include <diapp_pacmod3_msgs_s12n01/msg/s12n01_actuate_cmd.hpp>
#include <diapp_pacmod3_msgs_s12n01/msg/s12n01_steer_cmd.hpp>
#include <diapp_pacmod3_msgs_s12n01/msg/s12n01_brake_cmd.hpp>
#include <diapp_pacmod3_msgs_s12n01/msg/s12n01_park_cmd.hpp>

#include <diapp_pacmod3_msgs_s12n01/msg/s12n01_actuate_rpt.hpp>
#include <diapp_pacmod3_msgs_s12n01/msg/s12n01_steer_rpt.hpp>
#include <diapp_pacmod3_msgs_s12n01/msg/s12n01_speed_rpt.hpp>
#include <diapp_pacmod3_msgs_s12n01/msg/s12n01_accel_rpt.hpp>
#include <diapp_pacmod3_msgs_s12n01/msg/s12n01_brake_rpt.hpp>
#include <diapp_pacmod3_msgs_s12n01/msg/s12n01_xbr_rpt.hpp>
#include <diapp_pacmod3_msgs_s12n01/msg/s12n01_whl_spd_rpt.hpp>
#include <diapp_pacmod3_msgs_s12n01/msg/s12n01_park_rpt.hpp>
#include <diapp_pacmod3_msgs_s12n01/msg/s12n01_brk_prs_rpt.hpp>
#include <diapp_pacmod3_msgs_s12n01/msg/s12n01_all_system_statuses.hpp>

// S12N01 反馈报文
#define S12n01_Actuate_Rpt  0x18F60421     // 驱动反馈报文
#define S12n01_Steer_Rpt    0x18F44213     // 转向反馈报文
#define S12n01_Speed_Rpt    0x18FEBF0B     // 车速反馈报文
#define S12n01_Accel_Rpt    0x18F0090B     // 纵向加速度反馈报文
#define S12n01_Brake_Rpt    0x18F0010B     // 制动反馈报文
#define S12n01_Xbr_Rpt      0x18FDC40B     // XBR反馈报文
#define S12n01_Whl_Spd_Rpt  0x08FE6E0B     // 轮速反馈报文
#define S12n01_Park_Rpt     0x18FE1264     // 驻车反馈报文
#define S12n01_Brk_Prs_Rpt  0x18FEAD0B     // 制动气压反馈报文

// S12N01 控制报文
#define S12n01_Actuate_Cmd  0x0CF605A0     // 驱动控制报文
#define S12n01_Steer_Cmd    0x18FF8213     // 转向控制报文
#define S12n01_Brake_Cmd    0x18F616A0     // 制动控制报文
#define S12n01_Park_Cmd     0x18EA64EF     // 驻车控制报文

namespace pacmod3
{
  class Pacmod3RxMsg
  {
  public:
    std::vector<uint8_t> data;
  };

  class Pacmod3TxMsg
  {
  public:
    static std::shared_ptr<Pacmod3TxMsg> make_message(const uint32_t &can_id);
    virtual void parse(const std::vector<uint8_t> &in) = 0;
    virtual void parse(const std::vector<uint8_t> &in, const double factor, const double offset);
    virtual bool isSystem();
  };

  // 0x0CF605A0 自动驾驶驱动控制报文
  class S12n01ActuateCmdMsg
      : public Pacmod3RxMsg
  {
  public:
    static constexpr uint8_t DATA_LENGTH = 8;
    static constexpr uint32_t CAN_ID = S12n01_Actuate_Cmd;

    void encode(
        uint8_t ctrl_mode,
        uint8_t shift_des,
        int torque);
  };

  // 0x18FF8213 自动驾驶转向控制报文
  class S12n01SteerCmdMsg
      : public Pacmod3RxMsg
  {
  public:
    static constexpr uint8_t DATA_LENGTH = 8;
    static constexpr uint32_t CAN_ID = S12n01_Steer_Cmd;

    void encode(
        float steer_angle,
        uint8_t steer_rate);
  };

  // 0x18F616A0 自动驾驶制动控制报文
  class S12n01BrakeCmdMsg
      : public Pacmod3RxMsg
  {
  public:
    static constexpr uint8_t DATA_LENGTH = 8;
    static constexpr uint32_t CAN_ID = S12n01_Brake_Cmd;

    void encode(
        float ex_acc_rqst,
        uint8_t cont_brk_mode,
        uint8_t xbr_priority,
        uint8_t xbr_mode);
  };

  // 0x18EA64EF 自动驾驶驻车控制报文
  class S12n01ParkCmdMsg
      : public Pacmod3RxMsg
  {
  public:
    static constexpr uint8_t DATA_LENGTH = 8;
    static constexpr uint32_t CAN_ID = S12n01_Park_Cmd;

    void encode(
        uint8_t epb_pct,
        uint8_t epb_mode);
  };

  // S12n01 Report
  class S12n01ActuateRptMsg
      : public Pacmod3TxMsg
  {
  public:
    static constexpr uint32_t CAN_ID = S12n01_Actuate_Rpt;

    uint8_t ctrl_mode;
    uint8_t gear_status;
    uint8_t act_sys_fault;
    double motor_rotation_speed;
    double max_torque;
    double actual_torque;
    uint8_t accel_pedal;

    void parse(const std::vector<uint8_t> &in);
  };
  class S12n01SteerRptMsg
      : public Pacmod3TxMsg
  {
  public:
    static constexpr uint32_t CAN_ID = S12n01_Steer_Rpt;

    double steer_torque;
    double steer_angle;
    uint16_t  steer_rate;
    uint8_t   control_status;

    void parse(const std::vector<uint8_t> &in);
  };
  class S12n01SpeedRptMsg
      : public Pacmod3TxMsg
  {
  public:
    static constexpr uint32_t CAN_ID = S12n01_Speed_Rpt;

    double vehicle_speed;

    void parse(const std::vector<uint8_t> &in);
  };
  class S12n01AccelRptMsg
      : public Pacmod3TxMsg
  {
  public:
    static constexpr uint32_t CAN_ID = S12n01_Accel_Rpt;

    double vehicle_accel;

    void parse(const std::vector<uint8_t> &in);
  };
  class S12n01BrakeRptMsg
      : public Pacmod3TxMsg
  {
  public:
    static constexpr uint32_t CAN_ID = S12n01_Brake_Rpt;

    uint8_t abs_status;
    uint8_t brake_pedal_flag;
    float brake_pedal_depth;
    uint8_t ebs_red_light;
    uint8_t ebs_yellow_light;

    void parse(const std::vector<uint8_t> &in);
  };
  class S12n01XbrRptMsg
      : public Pacmod3TxMsg
  {
  public:
    static constexpr uint32_t CAN_ID = S12n01_Xbr_Rpt;

    uint8_t xbr_status;
    uint8_t xbr_control_mode;

    void parse(const std::vector<uint8_t> &in);
  };
  class S12n01WhlSpdRptMsg
      : public Pacmod3TxMsg
  {
  public:
    static constexpr uint32_t CAN_ID = S12n01_Whl_Spd_Rpt;

    double steer_left_speed;
    double steer_right_speed;
    double drive_left_speed;
    double drive_right_speed;

    void parse(const std::vector<uint8_t> &in);
  };
  class S12n01ParkRptMsg
      : public Pacmod3TxMsg
  {
  public:
    static constexpr uint32_t CAN_ID = S12n01_Park_Rpt;

    uint8_t epb_status;
    uint8_t epb_fault;
    uint8_t epb_command_checksum;
    uint8_t epb_switch;
    uint8_t epb_work_status;

    void parse(const std::vector<uint8_t> &in);
  };
  class S12n01BrkPrsRptMsg
      : public Pacmod3TxMsg
  {
  public:
    static constexpr uint32_t CAN_ID = S12n01_Brk_Prs_Rpt;

    uint16_t one_left_bridge_brake;
    uint16_t one_right_bridge_brake;
    uint16_t two_left_bridge_brake;
    uint16_t two_right_bridge_brake;

    void parse(const std::vector<uint8_t> &in);
  };

} // namespace pacmod3

#endif // PACMOD3__PACMOD3_CORE_HPP_
