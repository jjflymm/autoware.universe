// Copyright (c) 2019 AutonomouStuff, LLC
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.

#ifndef PACMOD3__PACMOD3_NODE_HPP_
#define PACMOD3__PACMOD3_NODE_HPP_

#include <rclcpp/rclcpp.hpp>
#include <rclcpp_lifecycle/lifecycle_node.hpp>
#include <diapp_pacmod3_msgs_s12n01/msg/frame.hpp>
#include <std_msgs/msg/bool.hpp>
#include <std_msgs/msg/float64.hpp>

#include <chrono>
#include <map>
#include <memory>
#include <string>
#include <thread>
#include <tuple>
#include <utility>
#include <unordered_map>

#include "pacmod3_common.hpp"
#include "pacmod3_ros_msg_handler.hpp"

namespace lc = rclcpp_lifecycle;
using LNI = rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface;

namespace pacmod3
{

  /// \brief PACMod3Node class which can translate messages
  /// being sent to or from a PACMod drive-by-wire system.
  class PACMod3Node final
      : public lc::LifecycleNode
  {
  public:
    /// \brief Default constructor
    explicit PACMod3Node(rclcpp::NodeOptions options);
    virtual ~PACMod3Node();

    /// \brief Callback from transition to "configuring" state.
    /// \param[in] state The current state that the node is in.
    LNI::CallbackReturn on_configure(const lc::State &state) override;

    /// \brief Callback from transition to "activating" state.
    /// \param[in] state The current state that the node is in.
    LNI::CallbackReturn on_activate(const lc::State &state) override;

    /// \brief Callback from transition to "deactivating" state.
    /// \param[in] state The current state that the node is in.
    LNI::CallbackReturn on_deactivate(const lc::State &state) override;

    /// \brief Callback from transition to "unconfigured" state.
    /// \param[in] state The current state that the node is in.
    LNI::CallbackReturn on_cleanup(const lc::State &state) override;

    /// \brief Callback from transition to "shutdown" state.
    /// \param[in] state The current state that the node is in.
    LNI::CallbackReturn on_shutdown(const lc::State &state) override;

    /// \brief Callback from transition to "error" state.
    /// \param[in] state The current state that the node is in.
    LNI::CallbackReturn on_error(const lc::State &state) override;

  private:
    // void initializeApiForMsg(uint32_t msg_can_id);

    void callback_can_tx(const diapp_pacmod3_msgs_s12n01::msg::Frame::SharedPtr msg);
    // S12N01
    void callback_s12n01_actuate_cmd(const diapp_pacmod3_msgs_s12n01::msg::S12n01ActuateCmd::SharedPtr msg);
    void callback_s12n01_steer_cmd(const diapp_pacmod3_msgs_s12n01::msg::S12n01SteerCmd::SharedPtr msg);
    void callback_s12n01_brake_cmd(const diapp_pacmod3_msgs_s12n01::msg::S12n01BrakeCmd::SharedPtr msg);
    void callback_s12n01_park_cmd(const diapp_pacmod3_msgs_s12n01::msg::S12n01ParkCmd::SharedPtr msg);

    template <class T>
    // 对上层的控制指令 topic 进行解析和编码
    void lookup_and_encode(const unsigned int &can_id, const T &msg)
    {
      auto cmd = can_subs_.find(can_id);

      if (cmd != can_subs_.end())
      {
        cmd->second.second->setData(Pacmod3RxRosMsgHandler::unpackAndEncode(can_id, msg));
      }
      else
      {
        RCLCPP_WARN(
            this->get_logger(),
            "Received a command message for ID 0x%x for which we do not have an encoder.",
            can_id);
      }
    }

    void publish_cmds(); // 将控制命令的 can topic 发送给下层
    void publish_all_system_statuses();
    void set_enable(bool enable);

    static constexpr auto SEND_CMD_INTERVAL = std::chrono::milliseconds(33);
    static constexpr auto INTER_MSG_PAUSE = std::chrono::milliseconds(1);

    std::string frame_id_;
    unsigned int dbc_major_version_;
    Pacmod3TxRosMsgHandler tx_handler_;
    std::map<unsigned int, std::tuple<bool, bool, bool>> system_statuses;

    std::shared_ptr<rclcpp::TimerBase> system_statuses_timer_;
    std::shared_ptr<lc::LifecyclePublisher<diapp_pacmod3_msgs_s12n01::msg::Frame>> pub_can_rx_;
#ifdef ROS_DISTRO_GALACTIC
    std::unordered_map<unsigned int, std::shared_ptr<lc::LifecyclePublisherInterface>> can_pubs_;
#else
    std::unordered_map<unsigned int, std::shared_ptr<lc::ManagedEntityInterface>> can_pubs_;
#endif
    std::shared_ptr<lc::LifecyclePublisher<std_msgs::msg::Bool>> pub_enabled_;
    std::shared_ptr<lc::LifecyclePublisher<diapp_pacmod3_msgs_s12n01::msg::S12n01AllSystemStatuses>>
        pub_all_system_statuses_;

    std::shared_ptr<rclcpp::Subscription<diapp_pacmod3_msgs_s12n01::msg::Frame>> sub_can_tx_;
    std::unordered_map<unsigned int,
                       std::pair<std::shared_ptr<rclcpp::SubscriptionBase>,
                                 std::shared_ptr<LockedData>>>
        can_subs_;

    std::shared_ptr<std::thread> pub_thread_;
  };

} // namespace pacmod3

#endif // PACMOD3__PACMOD3_NODE_HPP_
