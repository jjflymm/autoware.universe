// Copyright (c) 2019 AutonomouStuff, LLC
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.

#ifndef PACMOD3__PACMOD3_ROS_MSG_HANDLER_HPP_
#define PACMOD3__PACMOD3_ROS_MSG_HANDLER_HPP_

#include <rclcpp_lifecycle/lifecycle_publisher.hpp>

#include <memory>
#include <string>
#include <vector>

#include "pacmod3_common.hpp"

#define RAD2DEG 57.296
#define DEG2RAD 0.0175

namespace lc = rclcpp_lifecycle;

namespace pacmod3
{

  class LockedData
  {
  public:
    explicit LockedData(unsigned char data_length);

    std::vector<unsigned char> getData() const;
    void setData(std::vector<unsigned char> &&new_data);

  private:
    std::vector<unsigned char> _data;
    mutable std::mutex _data_mut;
  };

  class Pacmod3TxRosMsgHandler
  {
  public:
    void fillAndPublish(
        const uint32_t &can_id,
        const std::string &frame_id,
#ifdef ROS_DISTRO_GALACTIC
        const std::shared_ptr<lc::LifecyclePublisherInterface> &pub,
#else
        const std::shared_ptr<lc::ManagedEntityInterface> &pub,
#endif
        const std::shared_ptr<Pacmod3TxMsg> &parser_class);

  private:

    void fillS12n01AccelRpt(
      const std::shared_ptr<Pacmod3TxMsg> &parser_class,
      diapp_pacmod3_msgs_s12n01::msg::S12n01AccelRpt *const new_msg,
      const std::string &frame_id);
    void fillS12n01ActuateRpt(
      const std::shared_ptr<Pacmod3TxMsg> &parser_class,
      diapp_pacmod3_msgs_s12n01::msg::S12n01ActuateRpt *const new_msg,
      const std::string &frame_id);
    void fillS12n01BrakeRpt(
      const std::shared_ptr<Pacmod3TxMsg> &parser_class,
      diapp_pacmod3_msgs_s12n01::msg::S12n01BrakeRpt *const new_msg,
      const std::string &frame_id);
    void fillS12n01BrkPrsRpt(
      const std::shared_ptr<Pacmod3TxMsg> &parser_class,
      diapp_pacmod3_msgs_s12n01::msg::S12n01BrkPrsRpt *const new_msg,
      const std::string &frame_id);
    void fillS12n01ParkRpt(
      const std::shared_ptr<Pacmod3TxMsg> &parser_class,
      diapp_pacmod3_msgs_s12n01::msg::S12n01ParkRpt *const new_msg,
      const std::string &frame_id);
    void fillS12n01SpeedRpt(
      const std::shared_ptr<Pacmod3TxMsg> &parser_class,
      diapp_pacmod3_msgs_s12n01::msg::S12n01SpeedRpt *const new_msg,
      const std::string &frame_id);
    void fillS12n01SteerRpt(
      const std::shared_ptr<Pacmod3TxMsg> &parser_class,
      diapp_pacmod3_msgs_s12n01::msg::S12n01SteerRpt *const new_msg,
      const std::string &frame_id);
    void fillS12n01WhlSpdRpt(
      const std::shared_ptr<Pacmod3TxMsg> &parser_class,
      diapp_pacmod3_msgs_s12n01::msg::S12n01WhlSpdRpt *const new_msg,
      const std::string &frame_id);
    void fillS12n01XbrRpt(
      const std::shared_ptr<Pacmod3TxMsg> &parser_class,
      diapp_pacmod3_msgs_s12n01::msg::S12n01XbrRpt *const new_msg,
      const std::string &frame_id);
  };

  class Pacmod3RxRosMsgHandler
  {
  public:
    // S12N01
    static std::vector<uint8_t> unpackAndEncode(
        const uint32_t &can_id, const diapp_pacmod3_msgs_s12n01::msg::S12n01ActuateCmd::SharedPtr &msg);
    static std::vector<uint8_t> unpackAndEncode(
        const uint32_t &can_id, const diapp_pacmod3_msgs_s12n01::msg::S12n01BrakeCmd::SharedPtr &msg);
    static std::vector<uint8_t> unpackAndEncode(
        const uint32_t &can_id, const diapp_pacmod3_msgs_s12n01::msg::S12n01ParkCmd::SharedPtr &msg);
    static std::vector<uint8_t> unpackAndEncode(
        const uint32_t &can_id, const diapp_pacmod3_msgs_s12n01::msg::S12n01SteerCmd::SharedPtr &msg);
    /*
    static std::vector<uint8_t> unpackAndEncode(
        const uint32_t &can_id, const diapp_pacmod3_msgs_s12n01::msg::T018TurnLightCmd::SharedPtr &msg);
    */
  };

} // namespace pacmod3

#endif // PACMOD3__PACMOD3_ROS_MSG_HANDLER_HPP_
