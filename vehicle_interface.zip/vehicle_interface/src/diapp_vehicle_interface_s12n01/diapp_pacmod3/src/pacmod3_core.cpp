// Copyright (c) 2019 AutonomouStuff, LLC
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.

#include <memory>
#include <vector>
#include <iostream>
#include <rclcpp/rclcpp.hpp>
#include "pacmod3_core.hpp"

namespace pacmod3
{

  // S12n01 Reports
  constexpr uint32_t S12n01AccelRptMsg::CAN_ID;
  constexpr uint32_t S12n01ActuateRptMsg::CAN_ID;
  constexpr uint32_t S12n01BrakeRptMsg::CAN_ID;
  constexpr uint32_t S12n01BrkPrsRptMsg::CAN_ID;
  constexpr uint32_t S12n01ParkRptMsg::CAN_ID;
  constexpr uint32_t S12n01SpeedRptMsg::CAN_ID;
  constexpr uint32_t S12n01SteerRptMsg::CAN_ID;
  constexpr uint32_t S12n01WhlSpdRptMsg::CAN_ID;
  constexpr uint32_t S12n01XbrRptMsg::CAN_ID;

  std::shared_ptr<Pacmod3TxMsg> Pacmod3TxMsg::make_message(const uint32_t &can_id)
  {
    switch (can_id)
    {
    case S12n01AccelRptMsg::CAN_ID:
      return std::shared_ptr<Pacmod3TxMsg>(new S12n01AccelRptMsg);
      break;
    case S12n01ActuateRptMsg::CAN_ID:
      return std::shared_ptr<Pacmod3TxMsg>(new S12n01ActuateRptMsg);
      break;
    case S12n01BrakeRptMsg::CAN_ID:
      return std::shared_ptr<Pacmod3TxMsg>(new S12n01BrakeRptMsg);
      break;
    case S12n01BrkPrsRptMsg::CAN_ID:
      return std::shared_ptr<Pacmod3TxMsg>(new S12n01BrkPrsRptMsg);
      break;
    case S12n01ParkRptMsg::CAN_ID:
      return std::shared_ptr<Pacmod3TxMsg>(new S12n01ParkRptMsg);
      break;
    case S12n01SpeedRptMsg::CAN_ID:
      return std::shared_ptr<Pacmod3TxMsg>(new S12n01SpeedRptMsg);
      break;
    case S12n01SteerRptMsg::CAN_ID:
      return std::shared_ptr<Pacmod3TxMsg>(new S12n01SteerRptMsg);
      break;
    case S12n01WhlSpdRptMsg::CAN_ID:
      return std::shared_ptr<Pacmod3TxMsg>(new S12n01WhlSpdRptMsg);
      break;
    case S12n01XbrRptMsg::CAN_ID:
      return std::shared_ptr<Pacmod3TxMsg>(new S12n01XbrRptMsg);
      break;
    default:
      return nullptr;
    }
  }

  void Pacmod3TxMsg::parse(const std::vector<uint8_t> &, const double, const double)
  {
    return;
  }

  bool Pacmod3TxMsg::isSystem()
  {
    return false;
  }

  /* S12n01 can topic parse, transform INT value into PH value */        //S12n01 report parse function.Transform INT value into PH value.


  // 0x18F0421 驱动反馈报文
  void S12n01ActuateRptMsg::parse(const std::vector<uint8_t> &in)
  {
    ctrl_mode     = (in[0]) & 0x03;                                       // 1.0-1.1 驱动控制状态
    gear_status   = (in[0] & 0x0C) >> 2;                                  // 1.2-1.3 车辆实际挡位
    act_sys_fault = (in[0] & 0x30) >> 4;                                  // 1.4-1.5 驱动系统故障状态
    motor_rotation_speed = (static_cast<uint16_t>(in[2]) << 8) | in[1];   // 2.0-3.7 电机转速
    max_torque = ((static_cast<uint16_t>(in[4]) << 8) | in[3]) * 0.1;     // 4.0-5.7 输出最大扭矩能力
    actual_torque = ((static_cast<uint16_t>(in[6]) << 8) | in[5]) * 0.1;  // 6.0-7.7 实际驱动扭矩
    accel_pedal= in[7];                                                   // 8.0-8.7 加速踏板深度
  }

  // 0x18F44213 转向反馈报文
  void S12n01SteerRptMsg::parse(const std::vector<uint8_t> &in)
  {
    steer_torque = in[1] * 0.07 - 8.96;                                   // 2.0-2.7 方向盘当前实际扭矩反馈
    int16_t steer_angle_tmp = (static_cast<uint16_t>(in[3]) << 8) | in[2];
    steer_angle = steer_angle_tmp * 0.1 - 1575;                           // 3.0-4.7 方向盘当前转向角
    steer_rate = in[5] * 10;                                              // 6.0-6.7 方向盘当前角速度
    control_status = in[6] & 0x0F;                                        // 7.0-7.3 控制位状态
  }

  // 0x18FEBF0B 车速反馈报文
  void S12n01SpeedRptMsg::parse(const std::vector<uint8_t> &in)
  {
    uint16_t vehicle_speed_tmp = (static_cast<uint16_t>(in[1]) << 8) | in[0];
    vehicle_speed = vehicle_speed_tmp * 0.00390625;                       // 1.0-2.7 当前车速
  }

  // 0x18F0090B 加速度反馈报文
  void S12n01AccelRptMsg::parse(const std::vector<uint8_t> &in)
  {
    vehicle_accel = in[7] * 0.1 - 12.5;                                   // 8.0-8.7 纵向加速度
  }

  //0x18F0010B 制动系统状态反馈报文
  void S12n01BrakeRptMsg::parse(const std::vector<uint8_t> &in)
  {
    abs_status = (in[0] & 0x30) >> 4;                                     // 1.4-1.5 ABS激活状态
    brake_pedal_flag = (in[0] & 0xC0) >> 6;                               // 1.6-1.7 制动踏板开关信号
    brake_pedal_depth = in[1] * 0.4;                                      // 2.0-2.7 制动踏板深度
    ebs_red_light = (in[5] & 0x0C) >> 2;                                  // 6.2-6.3 EBS红灯状态
    ebs_yellow_light = (in[5] & 0x30) >> 4;                               // 6.4-6.5 EBS黄灯状态
  }

  //0x18FDC40B 制动反馈报文
  void S12n01XbrRptMsg::parse(const std::vector<uint8_t> &in)
  {
    xbr_status = (in[1] & 0x0C) >> 2;                                      // 2.2-2.3 XBR状态
    xbr_control_mode = (in[1] & 0xF0) >> 4;                                // 2.4-2.7 XBR启动控制模式
  }

  // 0x08FE6E0B 轮速反馈报文
  void S12n01WhlSpdRptMsg::parse(const std::vector<uint8_t> &in)
  {
    uint16_t steer_left_speed_tmp = (static_cast<uint16_t>(in[1]) << 8) | in[0];
    uint16_t steer_right_speed_tmp = (static_cast<uint16_t>(in[3]) << 8) | in[2];
    uint16_t drive_left_speed_tmp = (static_cast<uint16_t>(in[5]) << 8) | in[4];
    uint16_t drive_right_speed_tmp = (static_cast<uint16_t>(in[7]) << 8) | in[6];
    steer_left_speed = steer_left_speed_tmp * 0.00390625;                  // 1.0-2.7 左前轮速
    steer_right_speed = steer_right_speed_tmp * 0.00390625;                // 3.0-4.7 右前轮速
    drive_left_speed = drive_left_speed_tmp * 0.00390625;                  // 5.0-6.7 左后轮速
    drive_right_speed = drive_right_speed_tmp * 0.00390625;                // 7.0-8.7 右后轮速
  }

  // 0x18FE1264 驻车系统状态反馈报文
  void S12n01ParkRptMsg::parse(const std::vector<uint8_t> &in)
  {
    epb_status = in[0] & 0x03;                                             // 1.0-1.1 驻车执行状态
    epb_fault = in[1];                                                     // 2.0-2.7 驻车故障状态
    epb_command_checksum = (in[2] & 0x30) >> 4;                            // 3.4-3.5 驻车命令校验码状态
    epb_switch = in[4] & 0x03;                                             // 5.0-5.1 驻车开关状态
    epb_work_status = (in[5] & 0xC0) >> 6;                                 // 6.6-6.7 驻车工作模式状态
  }

  // 0x18FEAD0B 制动气室气压反馈报文
  void S12n01BrkPrsRptMsg::parse(const std::vector<uint8_t> &in)
  {
    one_left_bridge_brake  = in[0] * 5;                                    // 1.0-1.7 1桥左制动压力
    one_right_bridge_brake = in[1] * 5;                                    // 2.0-2.7 1桥右制动压力
    two_left_bridge_brake  = in[2] * 5;                                    // 3.0-3.7 2桥左制动压力
    two_right_bridge_brake = in[3] * 5;                                    // 4.0-4.7 2桥右制动压力
  }

  /* Encode control cmd to can topic */
  // 0x0CF605A0 自动驾驶驱动控制报文，这里计算时是根据 PH 物理值计算得出给底盘的 INT 内部值
  void S12n01ActuateCmdMsg::encode(
      uint8_t ctrl_mode,
      uint8_t shift_des,
      int torque)
  {
    data.assign(DATA_LENGTH, 0);
    data[0] = (ctrl_mode     ) | data[0];                                  // 1.0~1.1 驱动控制模式
    data[0] = (shift_des << 2) | data[0];                                  // 1.2~1.5 车辆目标档位
    data[0] = (0x03      << 6) | data[0];                                  // 1.6~1.7 预留,填充1
    data[1] = ((uint16_t)(torque * 10));
    data[2] = ((uint16_t)(torque * 10)) >> 8;                              // 2.0~3.7 请求驱动扭矩
    data[3] = 0xFF;
    data[4] = 0xFF;
    data[5] = 0xFF;
    data[6] = 0xFF;                                                        // 4.0~7.7 预留,填充1
    if(torque < 0)
    {
      torque = -torque;
      data[1] = ((uint16_t)(torque * 10));
      data[2] = (((uint16_t)(torque * 10)) >> 8) | 0x80;                   // 扭矩为负，正负符号标志位为1
    }
  }

  // 0x18FF8213 自动驾驶转向控制报文，这里计算时是根据 PH 物理值计算得出给底盘的 INT 内部值
  void S12n01SteerCmdMsg::encode(
      float steer_angle,
      uint8_t steer_rate)
  {
    data.assign(DATA_LENGTH, 0);
    data[0] = ((uint16_t)((steer_angle + 1575) * 10));
    data[1] = ((uint16_t)((steer_angle + 1575) * 10)) >> 8; // 1.0~2.7 转角命令
    data[2] = (0x1     ) | data[2];                         // 3.0~3.3 工作模式指令（先默认发自动驾驶模式指令）
    data[2] = (0xF << 4) | data[2];                         // 3.4~3.7 预留,填充1
    data[3] = 0x80;                                         // 4.0~4.7 预留,发0x80
    data[4] = steer_rate * 0.1;                             // 5.0~5.7 角速度命令
    data[5] = 0xFF;
    data[6] = 0xFF;                                         // 6.0~7.7 预留,填充1
  }

  // 0x18F616A0 自动驾驶制动控制报文，这里计算时是根据 PH 物理值计算得出给底盘的 INT 内部值
  void S12n01BrakeCmdMsg::encode(
      float ex_acc_rqst,
      uint8_t cont_brk_mode,
      uint8_t xbr_priority,
      uint8_t xbr_mode)
  {
    using diapp_pacmod3_msgs_s12n01::msg::S12n01BrakeCmd;
    data.assign(DATA_LENGTH, 0);
    uint16_t ex_acc_rqst_inter = (ex_acc_rqst + 15.687) * 2048;
    if (S12n01BrakeCmd::NO_XBR_REQUEST == ex_acc_rqst)
    {
      ex_acc_rqst_inter = S12n01BrakeCmd::NO_XBR_REQUEST;
    }
    data[0] = (ex_acc_rqst_inter);
    data[1] = (ex_acc_rqst_inter) >> 8;                     // 1.0~2.7 外部加速度请求
    data[2] = (cont_brk_mode    ) | data[2];                // 3.0~3.1 持续制动参与模式
    data[2] = (xbr_priority << 2) | data[2];                // 3.2~3.3 XBR优先级
    data[2] = (xbr_mode     << 4) | data[2];                // 3.4~3.5 XBR控制模式
    data[2] = (0x03         << 6) | data[2];
    data[3] = 0xFF;
    data[4] = 0xFF;
    data[5] = 0xFF;
    data[6] = 0xFF;                                         // 3.6~7.7 预留,填充1
  }

  // 0x18EA64EF 自动驾驶驻车控制报文
  void S12n01ParkCmdMsg::encode(
      uint8_t epb_pct,
      uint8_t epb_mode)
  {
    data.assign(DATA_LENGTH, 0);
                                             // 1.0~4.7 预留,填充0
    data[4] = epb_pct;                       // 5.0~5.7 驻车开关控制(入参epb_pct已经是INT 0/251)
                                             // 6.0~6.7 预留,填充0
    data[6] = epb_mode;                      // 7.0~7.7 驻车工作模式
  }
} // namespace pacmod3
