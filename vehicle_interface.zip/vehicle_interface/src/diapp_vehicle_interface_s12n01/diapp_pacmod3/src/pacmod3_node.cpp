// Copyright (c) 2019 AutonomouStuff, LLC
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.

#include <lifecycle_msgs/msg/state.hpp>

#include <chrono>
#include <iostream>
#include <memory>
#include <string>
#include <tuple>
#include <utility>
#include <vector>

#include "pacmod3_node.hpp"

namespace lc = rclcpp_lifecycle; // 命名空间别名，简化长命名空间的使用

using LNI = rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface; // 类型别名

using namespace std::chrono_literals; // 使用命名空间std::chrono_literals，用于以简洁的方式定义时间量

namespace pacmod3
{
  constexpr std::chrono::milliseconds PACMod3Node::SEND_CMD_INTERVAL; // 定义PACMod3Node类的静态成员变量SEND_CMD_INTERVAL，表示发送命令的时间间隔
  constexpr std::chrono::milliseconds PACMod3Node::INTER_MSG_PAUSE;   // 定义PACMod3Node类的静态成员变量INTER_MSG_PAUSE，表示消息之间的暂停时间间隔

  PACMod3Node::PACMod3Node(rclcpp::NodeOptions options)
      : lc::LifecycleNode("pacmod3_driver", options) // 构造函数，创建一个名为"pacmod3_driver"的lifecycle节点
  {
    frame_id_ = this->declare_parameter("frame_id", "pacmod");            // 获取参数"frame_id"的值，如果未设置则使用默认值"pacmod"
    dbc_major_version_ = this->declare_parameter("dbc_major_version", 3); // 获取参数"dbc_major_version"的值，如果未设置则使用默认值3

    RCLCPP_INFO(this->get_logger(), "frame_id: %s", frame_id_.c_str());           // 打印日志，输出frame_id的值
    RCLCPP_INFO(this->get_logger(), "dbc_major_version: %d", dbc_major_version_); // 打印日志，输出dbc_major_version的值

    if (dbc_major_version_ != 3)
    {
      RCLCPP_ERROR(
          this->get_logger(),
          "This driver currently only supports PACMod DBC version 3"); // 打印错误日志，表示该驱动器只支持PACMod DBC版本3
      rclcpp::shutdown();                                              // 关闭ROS节点
    }
  }

  PACMod3Node::~PACMod3Node()
  {
    if (pub_thread_ && pub_thread_->joinable())
    {
      pub_thread_->join(); // 等待发布线程结束
    }
  }

  LNI::CallbackReturn PACMod3Node::on_configure(const lc::State &state)
  {
    (void)state; // 忽略未使用的参数state
    /* Sub */
    sub_can_tx_ =
        this->create_subscription<diapp_pacmod3_msgs_s12n01::msg::Frame>(
            "can_to_pacmod_rpt", 100,
            std::bind(&PACMod3Node::callback_can_tx, this, std::placeholders::_1));

    // Commands common to all platforms
    can_subs_[S12n01ActuateCmdMsg::CAN_ID] = std::make_pair(
        this->create_subscription<diapp_pacmod3_msgs_s12n01::msg::S12n01ActuateCmd>(
            "/pacmod_interface/s12n01_actuate_cmd", 20,
            std::bind(&PACMod3Node::callback_s12n01_actuate_cmd, this, std::placeholders::_1)),
        std::shared_ptr<LockedData>(new LockedData(S12n01ActuateCmdMsg::DATA_LENGTH)));
    can_subs_[S12n01SteerCmdMsg::CAN_ID] = std::make_pair(
        this->create_subscription<diapp_pacmod3_msgs_s12n01::msg::S12n01SteerCmd>(
            "/pacmod_interface/s12n01_steer_cmd", 20,
            std::bind(&PACMod3Node::callback_s12n01_steer_cmd, this, std::placeholders::_1)),
        std::shared_ptr<LockedData>(new LockedData(S12n01SteerCmdMsg::DATA_LENGTH)));
    can_subs_[S12n01BrakeCmdMsg::CAN_ID] = std::make_pair(
        this->create_subscription<diapp_pacmod3_msgs_s12n01::msg::S12n01BrakeCmd>(
            "/pacmod_interface/s12n01_brake_cmd", 20,
            std::bind(&PACMod3Node::callback_s12n01_brake_cmd, this, std::placeholders::_1)),
        std::shared_ptr<LockedData>(new LockedData(S12n01BrakeCmdMsg::DATA_LENGTH)));
    can_subs_[S12n01ParkCmdMsg::CAN_ID] = std::make_pair(
        this->create_subscription<diapp_pacmod3_msgs_s12n01::msg::S12n01ParkCmd>(
            "/pacmod_interface/s12n01_park_cmd", 20,
            std::bind(&PACMod3Node::callback_s12n01_park_cmd, this, std::placeholders::_1)),
        std::shared_ptr<LockedData>(new LockedData(S12n01ParkCmdMsg::DATA_LENGTH)));

    /* Pub */
    pub_can_rx_ =
        this->create_publisher<diapp_pacmod3_msgs_s12n01::msg::Frame>("pacmod_to_can_cmd", 100);
    // Reports common to all platforms

    can_pubs_[S12n01ActuateRptMsg::CAN_ID] =
        this->create_publisher<diapp_pacmod3_msgs_s12n01::msg::S12n01ActuateRpt>("s12n01_actuate_rpt", 20);
    can_pubs_[S12n01SteerRptMsg::CAN_ID] =
        this->create_publisher<diapp_pacmod3_msgs_s12n01::msg::S12n01SteerRpt>("s12n01_steer_rpt", 20);
    can_pubs_[S12n01SpeedRptMsg::CAN_ID] =
        this->create_publisher<diapp_pacmod3_msgs_s12n01::msg::S12n01SpeedRpt>("s12n01_speed_rpt", 20);
    can_pubs_[S12n01AccelRptMsg::CAN_ID] =
        this->create_publisher<diapp_pacmod3_msgs_s12n01::msg::S12n01AccelRpt>("s12n01_accel_rpt", 20);
    can_pubs_[S12n01BrakeRptMsg::CAN_ID] =
        this->create_publisher<diapp_pacmod3_msgs_s12n01::msg::S12n01BrakeRpt>("s12n01_brake_rpt", 20);
    can_pubs_[S12n01XbrRptMsg::CAN_ID] =
        this->create_publisher<diapp_pacmod3_msgs_s12n01::msg::S12n01XbrRpt>("s12n01_xbr_rpt", 20);
    can_pubs_[S12n01WhlSpdRptMsg::CAN_ID] =
        this->create_publisher<diapp_pacmod3_msgs_s12n01::msg::S12n01WhlSpdRpt>("s12n01_whl_spd_rpt", 20);
    can_pubs_[S12n01ParkRptMsg::CAN_ID] =
        this->create_publisher<diapp_pacmod3_msgs_s12n01::msg::S12n01ParkRpt>("s12n01_park_rpt", 20);
    can_pubs_[S12n01BrkPrsRptMsg::CAN_ID] =
        this->create_publisher<diapp_pacmod3_msgs_s12n01::msg::S12n01BrkPrsRpt>("s12n01_brk_prs_rpt", 20);

    pub_enabled_ =
        this->create_publisher<std_msgs::msg::Bool>("enabled", rclcpp::QoS(1).transient_local());
    pub_all_system_statuses_ =
        this->create_publisher<diapp_pacmod3_msgs_s12n01::msg::S12n01AllSystemStatuses>("s12n01_all_system_statuses", 20);

    pub_thread_ = std::make_shared<std::thread>();

    system_statuses_timer_ = this->create_wall_timer(
        33ms, std::bind(&PACMod3Node::publish_all_system_statuses, this));

    return LNI::CallbackReturn::SUCCESS;
  }

  LNI::CallbackReturn PACMod3Node::on_activate(const lc::State &state)
  {
    (void)state;

    pub_can_rx_->on_activate();

    for (auto &pub : can_pubs_)
    {
      pub.second->on_activate();
    }

    pub_enabled_->on_activate();
    pub_all_system_statuses_->on_activate();

    pub_thread_ = std::make_shared<std::thread>(std::bind(&PACMod3Node::publish_cmds, this));

    return LNI::CallbackReturn::SUCCESS;
  }

  LNI::CallbackReturn PACMod3Node::on_deactivate(const lc::State &state)
  {
    (void)state;

    pub_thread_->join();

    pub_can_rx_->on_deactivate();

    for (auto &pub : can_pubs_)
    {
      pub.second->on_deactivate();
    }

    pub_enabled_->on_deactivate();
    pub_all_system_statuses_->on_deactivate();

    // Reset all data in commands to 0
    for (auto &cmd : can_subs_)
    {
      auto data = cmd.second.second->getData();
      std::fill(data.begin(), data.end(), 0);
      cmd.second.second->setData(std::move(data));
    }

    return LNI::CallbackReturn::SUCCESS;
  }

  LNI::CallbackReturn PACMod3Node::on_cleanup(const lc::State &state)
  {
    (void)state;

    if (pub_thread_ && pub_thread_->joinable())
    {
      pub_thread_->join();
    }

    pub_thread_.reset();
    system_statuses_timer_.reset();

    sub_can_tx_.reset();
    can_subs_.clear();

    pub_can_rx_.reset();
    can_pubs_.clear();
    pub_enabled_.reset();
    pub_all_system_statuses_.reset();

    return LNI::CallbackReturn::SUCCESS;
  }

  LNI::CallbackReturn PACMod3Node::on_shutdown(const lc::State &state)
  {
    (void)state;

    if (pub_thread_ && pub_thread_->joinable())
    {
      pub_thread_->join();
    }

    pub_thread_.reset();

    return LNI::CallbackReturn::SUCCESS;
  }

  LNI::CallbackReturn PACMod3Node::on_error(const lc::State &state)
  {
    (void)state;

    if (pub_thread_ && pub_thread_->joinable())
    {
      pub_thread_->join();
    }

    pub_thread_.reset();

    return LNI::CallbackReturn::FAILURE;
  }

  void PACMod3Node::callback_can_tx(const diapp_pacmod3_msgs_s12n01::msg::Frame::SharedPtr msg)
  {
    // 1 make_message，实例化 pacmod3_core.cpp 中的 RptMsg
    auto parser_class = Pacmod3TxMsg::make_message(msg->id);
    auto pub = can_pubs_.find(msg->id);

    if (parser_class != nullptr && pub != can_pubs_.end())
    {
      // 2 parse，解析来自下层的 can topic
      const std::vector<uint8_t> data_copy(msg->data.begin(), msg->data.end());
      if(msg->id == S12n01ActuateRptMsg::CAN_ID)
      {
        parser_class->parse(data_copy);
      }
      else if(msg->id == S12n01SteerRptMsg::CAN_ID)
      {
        parser_class->parse(data_copy);
      }
      else if(msg->id == S12n01SpeedRptMsg::CAN_ID)
      {
        parser_class->parse(data_copy);
      }
      else if(msg->id == S12n01AccelRptMsg::CAN_ID)
      {
        parser_class->parse(data_copy);
      }
      else if(msg->id == S12n01BrakeRptMsg::CAN_ID)
      {
        parser_class->parse(data_copy);
      }
      else if(msg->id == S12n01XbrRptMsg::CAN_ID)
      {
        parser_class->parse(data_copy);
      }
      else if(msg->id == S12n01WhlSpdRptMsg::CAN_ID)
      {
        parser_class->parse(data_copy);
      }
      else if(msg->id == S12n01ParkRptMsg::CAN_ID)
      {
        parser_class->parse(data_copy);
      }
      else if(msg->id == S12n01BrkPrsRptMsg::CAN_ID)
      {
        parser_class->parse(data_copy);
      }

      // 3 fillAndPublish，解析后填充 rpt 的 topic，并发送给上层
      tx_handler_.fillAndPublish(msg->id, frame_id_, pub->second, parser_class);
    }
  }

  // S12N01
  void PACMod3Node::callback_s12n01_actuate_cmd(const diapp_pacmod3_msgs_s12n01::msg::S12n01ActuateCmd::SharedPtr msg)
  {
    lookup_and_encode(S12n01ActuateCmdMsg::CAN_ID, msg);
  }

  void PACMod3Node::callback_s12n01_steer_cmd(const diapp_pacmod3_msgs_s12n01::msg::S12n01SteerCmd::SharedPtr msg)
  {
    lookup_and_encode(S12n01SteerCmdMsg::CAN_ID, msg);
  }

  void PACMod3Node::callback_s12n01_brake_cmd(const diapp_pacmod3_msgs_s12n01::msg::S12n01BrakeCmd::SharedPtr msg)
  {
    lookup_and_encode(S12n01BrakeCmdMsg::CAN_ID, msg);
  }

  void PACMod3Node::callback_s12n01_park_cmd(const diapp_pacmod3_msgs_s12n01::msg::S12n01ParkCmd::SharedPtr msg)
  {
    lookup_and_encode(S12n01ParkCmdMsg::CAN_ID, msg);
  }

  // RAW

  void PACMod3Node::publish_cmds()
  {
    while (rclcpp::ok() &&
           this->get_current_state().id() == lifecycle_msgs::msg::State::PRIMARY_STATE_ACTIVE)
    {
      auto next_time = std::chrono::steady_clock::now() + SEND_CMD_INTERVAL;

      for (auto &cmd : can_subs_)
      {
        auto msg = std::make_unique<diapp_pacmod3_msgs_s12n01::msg::Frame>();
        auto data = cmd.second.second->getData();

        msg->id = cmd.first;
        msg->is_rtr = false;
        msg->is_extended = false;
        msg->is_error = false;
        msg->dlc = data.size();
        std::move(data.begin(), data.end(), msg->data.begin());

        pub_can_rx_->publish(std::move(msg));

        std::this_thread::sleep_for(INTER_MSG_PAUSE);
      }

      std::this_thread::sleep_until(next_time);
    }
  }

  void PACMod3Node::publish_all_system_statuses()
  {
    auto ss_msg = std::make_unique<diapp_pacmod3_msgs_s12n01::msg::S12n01AllSystemStatuses>();

    for (const auto &system : system_statuses)
    {
      diapp_pacmod3_msgs_s12n01::msg::S12n01KeyValuePair kvp;

      kvp.value = std::get<0>(system.second) ? "True" : "False";
      ss_msg->enabled_status.push_back(kvp);

      kvp.value = std::get<1>(system.second) ? "True" : "False";
      ss_msg->overridden_status.push_back(kvp);

      kvp.value = std::get<2>(system.second) ? "True" : "False";
      ss_msg->fault_status.push_back(kvp);
    }

    pub_all_system_statuses_->publish(std::move(ss_msg));
  }

  void PACMod3Node::set_enable(bool enable)
  {
    for (auto &cmd : can_subs_)
    {
      std::vector<uint8_t> current_data = cmd.second.second->getData();

      if (enable)
      {
        current_data[0] |= 0x01; // Set Enable True
      }
      else
      {
        current_data[0] &= 0xFE; // Set Enable False
      }

      cmd.second.second->setData(std::move(current_data));
    }
  }

} // namespace pacmod3

#include <rclcpp_components/register_node_macro.hpp> // NOLINT
RCLCPP_COMPONENTS_REGISTER_NODE(pacmod3::PACMod3Node)
