// Copyright (c) 2019 AutonomouStuff, LLC
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
// THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.

#include <rclcpp/rclcpp.hpp>
#include <rclcpp_lifecycle/lifecycle_publisher.hpp>

#include <vector>
#include <string>
#include <memory>

#include "pacmod3_ros_msg_handler.hpp"

namespace lc = rclcpp_lifecycle;

namespace pacmod3
{

  LockedData::LockedData(unsigned char data_length)
      : _data(),
        _data_mut()
  {
    _data.assign(data_length, 0);
  }

  std::vector<unsigned char> LockedData::getData() const
  {
    std::lock_guard<std::mutex> lck(_data_mut);
    return _data;
  }

  void LockedData::setData(std::vector<unsigned char> &&new_data)
  {
    std::lock_guard<std::mutex> lck(_data_mut);
    _data = new_data;
  }

  void Pacmod3TxRosMsgHandler::fillAndPublish(
      const uint32_t &can_id,
      const std::string &frame_id,
#ifdef ROS_DISTRO_GALACTIC
      const std::shared_ptr<lc::LifecyclePublisherInterface> &pub,
#else
      const std::shared_ptr<lc::ManagedEntityInterface> &pub,
#endif
      const std::shared_ptr<Pacmod3TxMsg> &parser_class)
  {
    // 根据 topic msg 的类型来选择发送对应类型的消息
    if(can_id == S12n01ActuateRptMsg::CAN_ID)
    {
      diapp_pacmod3_msgs_s12n01::msg::S12n01ActuateRpt new_msg;
      auto dc_pub = std::dynamic_pointer_cast<
          lc::LifecyclePublisher<diapp_pacmod3_msgs_s12n01::msg::S12n01ActuateRpt>>(pub);

      fillS12n01ActuateRpt(parser_class, &new_msg, frame_id);
      dc_pub->publish(new_msg);
    }
    else if(can_id == S12n01SteerRptMsg::CAN_ID)
    {
      diapp_pacmod3_msgs_s12n01::msg::S12n01SteerRpt new_msg;
      auto dc_pub = std::dynamic_pointer_cast<
          lc::LifecyclePublisher<diapp_pacmod3_msgs_s12n01::msg::S12n01SteerRpt>>(pub);

      fillS12n01SteerRpt(parser_class, &new_msg, frame_id);
      dc_pub->publish(new_msg);
    }
    else if(can_id == S12n01SpeedRptMsg::CAN_ID)
    {
      diapp_pacmod3_msgs_s12n01::msg::S12n01SpeedRpt new_msg;
      auto dc_pub = std::dynamic_pointer_cast<
          lc::LifecyclePublisher<diapp_pacmod3_msgs_s12n01::msg::S12n01SpeedRpt>>(pub);

      fillS12n01SpeedRpt(parser_class, &new_msg, frame_id);
      dc_pub->publish(new_msg);
    }
    else if(can_id == S12n01AccelRptMsg::CAN_ID)
    {
      diapp_pacmod3_msgs_s12n01::msg::S12n01AccelRpt new_msg;
      auto dc_pub = std::dynamic_pointer_cast<
          lc::LifecyclePublisher<diapp_pacmod3_msgs_s12n01::msg::S12n01AccelRpt>>(pub);

      fillS12n01AccelRpt(parser_class, &new_msg, frame_id);
      dc_pub->publish(new_msg);
    }
    else if(can_id == S12n01BrakeRptMsg::CAN_ID)
    {
      diapp_pacmod3_msgs_s12n01::msg::S12n01BrakeRpt new_msg;
      auto dc_pub = std::dynamic_pointer_cast<
          lc::LifecyclePublisher<diapp_pacmod3_msgs_s12n01::msg::S12n01BrakeRpt>>(pub);

      fillS12n01BrakeRpt(parser_class, &new_msg, frame_id);
      dc_pub->publish(new_msg);
    }
    else if(can_id == S12n01XbrRptMsg::CAN_ID)
    {
      diapp_pacmod3_msgs_s12n01::msg::S12n01XbrRpt new_msg;
      auto dc_pub = std::dynamic_pointer_cast<
          lc::LifecyclePublisher<diapp_pacmod3_msgs_s12n01::msg::S12n01XbrRpt>>(pub);

      fillS12n01XbrRpt(parser_class, &new_msg, frame_id);
      dc_pub->publish(new_msg);
    }
    else if(can_id == S12n01WhlSpdRptMsg::CAN_ID)
    {
      diapp_pacmod3_msgs_s12n01::msg::S12n01WhlSpdRpt new_msg;
      auto dc_pub = std::dynamic_pointer_cast<
          lc::LifecyclePublisher<diapp_pacmod3_msgs_s12n01::msg::S12n01WhlSpdRpt>>(pub);

      fillS12n01WhlSpdRpt(parser_class, &new_msg, frame_id);
      dc_pub->publish(new_msg);
    }
    else if(can_id == S12n01ParkRptMsg::CAN_ID)
    {
      diapp_pacmod3_msgs_s12n01::msg::S12n01ParkRpt new_msg;
      auto dc_pub = std::dynamic_pointer_cast<
          lc::LifecyclePublisher<diapp_pacmod3_msgs_s12n01::msg::S12n01ParkRpt>>(pub);

      fillS12n01ParkRpt(parser_class, &new_msg, frame_id);
      dc_pub->publish(new_msg);
    }
    else if(can_id == S12n01BrkPrsRptMsg::CAN_ID)
    {
      diapp_pacmod3_msgs_s12n01::msg::S12n01BrkPrsRpt new_msg;
      auto dc_pub = std::dynamic_pointer_cast<
          lc::LifecyclePublisher<diapp_pacmod3_msgs_s12n01::msg::S12n01BrkPrsRpt>>(pub);

      fillS12n01BrkPrsRpt(parser_class, &new_msg, frame_id);
      dc_pub->publish(new_msg);
    }
  }

  // Report messages
  // S12N01 Report
  void Pacmod3TxRosMsgHandler::fillS12n01ActuateRpt(
      const std::shared_ptr<Pacmod3TxMsg> &parser_class,
      diapp_pacmod3_msgs_s12n01::msg::S12n01ActuateRpt *const new_msg,
      const std::string &frame_id)
  {
    auto dc_parser = std::dynamic_pointer_cast<S12n01ActuateRptMsg>(parser_class);

    new_msg->ctrl_mode = dc_parser->ctrl_mode;
    new_msg->gear_status = dc_parser->gear_status;
    new_msg->act_sys_fault = dc_parser->act_sys_fault;
    new_msg->motor_rotation_speed = dc_parser->motor_rotation_speed;
    new_msg->max_torque = dc_parser->max_torque;
    new_msg->actual_torque = dc_parser->actual_torque;
    new_msg->accel_pedal = dc_parser->accel_pedal;

    new_msg->header.frame_id = frame_id;
    new_msg->header.stamp = rclcpp::Clock().now();
  }

  void Pacmod3TxRosMsgHandler::fillS12n01SteerRpt(
      const std::shared_ptr<Pacmod3TxMsg> &parser_class,
      diapp_pacmod3_msgs_s12n01::msg::S12n01SteerRpt *const new_msg,
      const std::string &frame_id)
  {
    auto dc_parser = std::dynamic_pointer_cast<S12n01SteerRptMsg>(parser_class);

    new_msg->steer_torque = dc_parser->steer_torque;
    new_msg->steer_angle = dc_parser->steer_angle;
    new_msg->steer_rate = dc_parser->steer_rate;
    new_msg->control_status = dc_parser->control_status;

    new_msg->header.frame_id = frame_id;
    new_msg->header.stamp = rclcpp::Clock().now();
  }

  void Pacmod3TxRosMsgHandler::fillS12n01SpeedRpt(
      const std::shared_ptr<Pacmod3TxMsg> &parser_class,
      diapp_pacmod3_msgs_s12n01::msg::S12n01SpeedRpt *const new_msg,
      const std::string &frame_id)
  {
    auto dc_parser = std::dynamic_pointer_cast<S12n01SpeedRptMsg>(parser_class);

    new_msg->vehicle_speed = dc_parser->vehicle_speed;

    new_msg->header.frame_id = frame_id;
    new_msg->header.stamp = rclcpp::Clock().now();
  }

  void Pacmod3TxRosMsgHandler::fillS12n01AccelRpt(
      const std::shared_ptr<Pacmod3TxMsg> &parser_class,
      diapp_pacmod3_msgs_s12n01::msg::S12n01AccelRpt *const new_msg,
      const std::string &frame_id)
  {
    auto dc_parser = std::dynamic_pointer_cast<S12n01AccelRptMsg>(parser_class);

    new_msg->vehicle_accel = dc_parser->vehicle_accel;

    new_msg->header.frame_id = frame_id;
    new_msg->header.stamp = rclcpp::Clock().now();
  }

  void Pacmod3TxRosMsgHandler::fillS12n01BrakeRpt(
      const std::shared_ptr<Pacmod3TxMsg> &parser_class,
      diapp_pacmod3_msgs_s12n01::msg::S12n01BrakeRpt *const new_msg,
      const std::string &frame_id)
  {
    auto dc_parser = std::dynamic_pointer_cast<S12n01BrakeRptMsg>(parser_class);

    new_msg->abs_status = dc_parser->abs_status;
    new_msg->brake_pedal_flag = dc_parser->brake_pedal_flag;
    new_msg->brake_pedal_depth = dc_parser->brake_pedal_depth;
    new_msg->ebs_red_light = dc_parser->ebs_red_light;
    new_msg->ebs_yellow_light = dc_parser->ebs_yellow_light;

    new_msg->header.frame_id = frame_id;
    new_msg->header.stamp = rclcpp::Clock().now();
  }

  void Pacmod3TxRosMsgHandler::fillS12n01XbrRpt(
      const std::shared_ptr<Pacmod3TxMsg> &parser_class,
      diapp_pacmod3_msgs_s12n01::msg::S12n01XbrRpt *const new_msg,
      const std::string &frame_id)
  {
    auto dc_parser = std::dynamic_pointer_cast<S12n01XbrRptMsg>(parser_class);

    new_msg->xbr_status = dc_parser->xbr_status;
    new_msg->xbr_control_mode = dc_parser->xbr_control_mode;

    new_msg->header.frame_id = frame_id;
    new_msg->header.stamp = rclcpp::Clock().now();
  }

  void Pacmod3TxRosMsgHandler::fillS12n01WhlSpdRpt(
      const std::shared_ptr<Pacmod3TxMsg> &parser_class,
      diapp_pacmod3_msgs_s12n01::msg::S12n01WhlSpdRpt *const new_msg,
      const std::string &frame_id)
  {
    auto dc_parser = std::dynamic_pointer_cast<S12n01WhlSpdRptMsg>(parser_class);

    new_msg->steer_left_speed = dc_parser->steer_left_speed;
    new_msg->steer_right_speed = dc_parser->steer_right_speed;
    new_msg->drive_left_speed = dc_parser->drive_left_speed;
    new_msg->drive_right_speed = dc_parser->drive_right_speed;

    new_msg->header.frame_id = frame_id;
    new_msg->header.stamp = rclcpp::Clock().now();
  }

  void Pacmod3TxRosMsgHandler::fillS12n01ParkRpt(
      const std::shared_ptr<Pacmod3TxMsg> &parser_class,
      diapp_pacmod3_msgs_s12n01::msg::S12n01ParkRpt *const new_msg,
      const std::string &frame_id)
  {
    auto dc_parser = std::dynamic_pointer_cast<S12n01ParkRptMsg>(parser_class);

    new_msg->epb_status = dc_parser->epb_status;
    new_msg->epb_fault = dc_parser->epb_fault;
    new_msg->epb_command_checksum = dc_parser->epb_command_checksum;
    new_msg->epb_switch = dc_parser->epb_switch;
    new_msg->epb_work_status = dc_parser->epb_work_status;

    new_msg->header.frame_id = frame_id;
    new_msg->header.stamp = rclcpp::Clock().now();
  }

  void Pacmod3TxRosMsgHandler::fillS12n01BrkPrsRpt(
      const std::shared_ptr<Pacmod3TxMsg> &parser_class,
      diapp_pacmod3_msgs_s12n01::msg::S12n01BrkPrsRpt *const new_msg,
      const std::string &frame_id)
  {
    auto dc_parser = std::dynamic_pointer_cast<S12n01BrkPrsRptMsg>(parser_class);

    new_msg->one_left_bridge_brake = dc_parser->one_left_bridge_brake;
    new_msg->one_right_bridge_brake = dc_parser->one_right_bridge_brake;
    new_msg->two_left_bridge_brake = dc_parser->two_left_bridge_brake;
    new_msg->two_right_bridge_brake = dc_parser->two_right_bridge_brake;

    new_msg->header.frame_id = frame_id;
    new_msg->header.stamp = rclcpp::Clock().now();
  }


  // S12N01 Command
  std::vector<uint8_t> Pacmod3RxRosMsgHandler::unpackAndEncode(
      const uint32_t &can_id,
      const diapp_pacmod3_msgs_s12n01::msg::S12n01ActuateCmd::SharedPtr &msg)
  {
    // Note: The clear_faults field has been removed in later DBC versions.
    // It is omitted here.

    // TODO(icolwell-as): should clear_faults be added back in here from global_cmd?
    if (can_id == S12n01ActuateCmdMsg::CAN_ID)
    {
      S12n01ActuateCmdMsg encoder;
      encoder.encode(
          msg->ctrl_mode,
          msg->shift_des,
          msg->torque);
      return encoder.data;
    }
    else
    {
      std::vector<uint8_t> bad_id;
      bad_id.assign(8, 0);
      return bad_id;
    }
  }

  std::vector<uint8_t> Pacmod3RxRosMsgHandler::unpackAndEncode(
      const uint32_t &can_id,
      const diapp_pacmod3_msgs_s12n01::msg::S12n01SteerCmd::SharedPtr &msg)
  {
    // Note: The clear_faults field has been removed in later DBC versions.
    // It is omitted here.

    // TODO(icolwell-as): should clear_faults be added back in here from global_cmd?
    if (can_id == S12n01SteerCmdMsg::CAN_ID)
    {
      S12n01SteerCmdMsg encoder;
      encoder.encode(
          msg->steer_angle,
          msg->steer_rate);
      return encoder.data;
    }
    else
    {
      std::vector<uint8_t> bad_id;
      bad_id.assign(8, 0);
      return bad_id;
    }
  }

  std::vector<uint8_t> Pacmod3RxRosMsgHandler::unpackAndEncode(
      const uint32_t &can_id,
      const diapp_pacmod3_msgs_s12n01::msg::S12n01BrakeCmd::SharedPtr &msg)
  {
    // Note: The clear_faults field has been removed in later DBC versions.
    // It is omitted here.

    // TODO(icolwell-as): should clear_faults be added back in here from global_cmd?
    if (can_id == S12n01BrakeCmdMsg::CAN_ID)
    {
      S12n01BrakeCmdMsg encoder;
      encoder.encode(
          msg->ex_acc_rqst,
          msg->cont_brk_mode,
          msg->xbr_priority,
          msg->xbr_mode);
      return encoder.data;
    }
    else
    {
      std::vector<uint8_t> bad_id;
      bad_id.assign(8, 0);
      return bad_id;
    }
  }

  std::vector<uint8_t> Pacmod3RxRosMsgHandler::unpackAndEncode(
      const uint32_t &can_id,
      const diapp_pacmod3_msgs_s12n01::msg::S12n01ParkCmd::SharedPtr &msg)
  {
    // Note: The clear_faults field has been removed in later DBC versions.
    // It is omitted here.

    // TODO(icolwell-as): should clear_faults be added back in here from global_cmd?
    if (can_id == S12n01ParkCmdMsg::CAN_ID)
    {
      S12n01ParkCmdMsg encoder;
      encoder.encode(
          msg->epb_pct,
          msg->epb_mode);
      return encoder.data;
    }
    else
    {
      std::vector<uint8_t> bad_id;
      bad_id.assign(8, 0);
      return bad_id;
    }
  }
} // namespace pacmod3
