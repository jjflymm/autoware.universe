#include <iostream>
#include <fstream>
#include <regex>
#include <vector>
#include <unistd.h>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <net/if.h>
#include <linux/can.h>
#include <rclcpp/rclcpp.hpp>
#include <diapp_pacmod3_msgs_s12n01/msg/frame.hpp>

#include "std_msgs/msg/int32.hpp"

// S12N01 反馈报文
#define S12n01_Actuate_Rpt  0x18F60421     // 驱动反馈报文
#define S12n01_Steer_Rpt    0x18F44213     // 转向反馈报文
#define S12n01_Speed_Rpt    0x18FEBF0B     // 车速反馈报文
#define S12n01_Accel_Rpt    0x18F0090B     // 纵向加速度反馈报文
#define S12n01_Brake_Rpt    0x18F0010B     // 制动反馈报文
#define S12n01_Xbr_Rpt      0x18FDC40B     // XBR反馈报文
#define S12n01_Whl_Spd_Rpt  0x08FE6E0B     // 轮速反馈报文
#define S12n01_Park_Rpt     0x18FE1264     // 驻车反馈报文
#define S12n01_Brk_Prs_Rpt  0x18FEAD0B     // 制动气压反馈报文

// S12N01 控制报文
#define S12n01_Actuate_Cmd  0x0CF605A0     // 驱动控制报文
#define S12n01_Steer_Cmd    0x18FF8213     // 转向控制报文
#define S12n01_Brake_Cmd    0x18F616A0     // 制动控制报文
#define S12n01_Park_Cmd     0x18EA64EF     // 驻车控制报文

int socketCan;
rclcpp::Publisher<diapp_pacmod3_msgs_s12n01::msg::Frame>::SharedPtr pub_can_topic_to_pacmod_;

// 构造 can 数据结构，用于存储读取的 txt 格式 can 数据
void fillCanRpt(const uint8_t *canData, uint8_t *data)
{
  int data_length = 8;
  memset(data, 0, data_length);
  for (int i = 0; i < data_length; ++i)
  {
    data[i] = canData[i];
  }
}

void pubCanTopicToPacmod(int canID, uint8_t *data)
{
  int data_length = 8;
  std::vector<uint8_t> dataV;
  dataV.assign(data_length, 0);
  auto canFrame = std::make_unique<diapp_pacmod3_msgs_s12n01::msg::Frame>();
  canFrame->dlc = 8;
  canFrame->is_error = false;
  canFrame->is_rtr = false;
  canFrame->is_extended = false;
  canFrame->id = canID;

  for (int i = 0; i < data_length; ++i)
  {
    dataV[i] = data[i];
  }
  std::move(dataV.begin(), dataV.end(), canFrame->data.begin());
  pub_can_topic_to_pacmod_->publish(std::move(canFrame));
}

// 在收到底盘 can 消息后填充 can frame 并转换为 ros topic 发布出去
void fillCanMsgAndPubToPacmod(const struct can_frame &frame)
{
  uint8_t data[8];
  uint32_t canID = frame.can_id & CAN_EFF_MASK;
  memset(&data, 0, sizeof(data));
  // 选择接收哪些 id 的 can 数据
  switch (canID)
  {
  case S12n01_Actuate_Rpt:
  {
    fillCanRpt(frame.data, data);
    pubCanTopicToPacmod(S12n01_Actuate_Rpt, data);
  }
  break;
  case S12n01_Steer_Rpt:
  {
    fillCanRpt(frame.data, data);
    pubCanTopicToPacmod(S12n01_Steer_Rpt, data);
  }
  break;
  case S12n01_Speed_Rpt:
  {
    fillCanRpt(frame.data, data);
    pubCanTopicToPacmod(S12n01_Speed_Rpt, data);
  }
  break;
  case S12n01_Accel_Rpt:
  {
    fillCanRpt(frame.data, data);
    pubCanTopicToPacmod(S12n01_Accel_Rpt, data);
  }
  break;
  case S12n01_Brake_Rpt:
  {
    fillCanRpt(frame.data, data);
    pubCanTopicToPacmod(S12n01_Brake_Rpt, data);
  }
  break;
  case S12n01_Xbr_Rpt:
  {
    fillCanRpt(frame.data, data);
    pubCanTopicToPacmod(S12n01_Xbr_Rpt, data);
  }
  break;
  case S12n01_Whl_Spd_Rpt:
  {
    fillCanRpt(frame.data, data);
    pubCanTopicToPacmod(S12n01_Whl_Spd_Rpt, data);
  }
  break;
  case S12n01_Park_Rpt:
  {
    fillCanRpt(frame.data, data);
    pubCanTopicToPacmod(S12n01_Park_Rpt, data);
  }
  break;
  case S12n01_Brk_Prs_Rpt:
  {
    fillCanRpt(frame.data, data);
    pubCanTopicToPacmod(S12n01_Brk_Prs_Rpt, data);
  }
  break;
  default:
    break;
  }
}

void *thread_can_receive(void *arg)
{
  (void)arg;
  int ret;
  struct can_frame frame;
  while (1)
  {
    // 从 socketCan 中读取 CAN 帧数据
    ret = read(socketCan, &frame, sizeof(frame));
    (void)ret;
    // 将接收到的 CAN 帧数据填充到 Pacmod 中并发布
    fillCanMsgAndPubToPacmod(frame);
  }
  // 关闭 socketCan 连接
  close(socketCan);
}
