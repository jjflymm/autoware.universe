#include <unistd.h>
#include <rclcpp/rclcpp.hpp>
#include <linux/can.h>
#include <diapp_pacmod3_msgs_s12n01/msg/frame.hpp>
#include <sys/socket.h>
#include <sys/ioctl.h>
#include <net/if.h>

#include <ament_index_cpp/get_package_share_directory.hpp>
#include <iostream>
#include <fstream>
#include <regex>
#include <vector>
#include "std_msgs/msg/int32.hpp"
#include "diapp_s12n01_can_rx_tx.hpp"

struct CanMessageStruct
{
  uint32_t id;
  std::vector<uint8_t> data;
};

class HazardController
{
private:
  bool is_pressed_{false};
  size_t pub_count_{0};
  const size_t MAX_PUB_COUNT_{100};

public:
  HazardController() = default;

  inline bool is_pressed() const { return is_pressed_; }
  inline void pressed_once() { is_pressed_ = true; };
  void change_hazard_status(struct can_frame &frame)
  {
    if (this->is_pressed_ && this->pub_count_ < this->MAX_PUB_COUNT_)
    {
      // byte 3.0-3.1 to 1
      frame.data[2] = frame.data[2] | 0x01;
      this->pub_count_++;
    }
    else
    {
      // byte 3.0-3.1 to 0
      frame.data[2] = frame.data[2] & 0xFC;
      this->is_pressed_ = false;
      this->pub_count_ = 0;
    }
  }
};

class CanMsgsNode : public rclcpp::Node
{
public:
  CanMsgsNode(const rclcpp::NodeOptions &opt) : Node("diapp_s12n01_can_rx_tx_node", opt)
  {
    // sub
    // 订阅 pacmod 传入的控制指令
    sub_can_topic_from_pacmod_ = this->create_subscription<diapp_pacmod3_msgs_s12n01::msg::Frame>(
        "/pacmod/pacmod_to_can_cmd", 100, std::bind(&CanMsgsNode::subCanTopicFromPacmod, this, std::placeholders::_1));
    // 订阅 rviz 中的按键指令
    sub_rviz_button_flag_ = this->create_subscription<std_msgs::msg::Int32>(
        "/diapp_rviz_panel/button_flag", 100, std::bind(&CanMsgsNode::subRvizButtonFlagMsg, this, std::placeholders::_1));

    // pub
    // 发布底盘反馈
    pub_can_topic_to_pacmod_ = this->create_publisher<diapp_pacmod3_msgs_s12n01::msg::Frame>(
        "/pacmod/can_to_pacmod_rpt", 100);
    // 发布控制指令是从 diapp 中读取更新，还是从 rviz 按键 txt 文件中读取更新，切换开关
    pub_can_switch_flag_msg_ = this->create_publisher<std_msgs::msg::Int32>(
        "/diapp_rviz_panel/can_switch_flag", rclcpp::QoS{1}.transient_local());

    // 从 /config/param.yaml 中读取数据
    this->declare_parameter<std::string>("can_name");
    can_name = this->get_parameter("can_name").as_string();
    send_frequency = this->declare_parameter<int>("send_frequency");
    gear_cnt_threshold = this->declare_parameter<int>("gear_cnt_threshold");
    park_recover_cnt_threshold = this->declare_parameter<int>("park_recover_cnt_threshold");

    initCanSocket();
  }

private:
  int send_frequency;
  int gear_cnt_threshold;
  int can_switch_flag = 1;
  std::string can_name;
  uint8_t msg_cnt = 0;
  uint8_t gear_cnt = 0;
  uint8_t previous_gear = 0;       // 上一帧挡位信息
  int s12n01_control_mode_cmd = 0; // 自驾模式指令：01 人工模式，02 自驾模式，03 错误模式
  int park_recover_cnt_threshold = 3;
  int park_recover_cnt = 0;
  int curr_park_mode = 0;
  bool park_recover_flag = false;

  struct sockaddr_can m_addr;
  pthread_t can_rcv_thread;
  rclcpp::TimerBase::SharedPtr timer_;
  std::unordered_map<int, struct can_frame> periodic_frame_map; // periodic_frame_map 的 key 是十六进制的 can id，value 里面是 can_frame，can_frame 中也有 can id

  std::shared_ptr<rclcpp::Subscription<diapp_pacmod3_msgs_s12n01::msg::Frame>> sub_can_topic_from_pacmod_;
  std::shared_ptr<rclcpp::Subscription<std_msgs::msg::Int32>> sub_rviz_button_flag_;
  std::shared_ptr<rclcpp::Publisher<std_msgs::msg::Int32>> pub_can_switch_flag_msg_;

  HazardController hazard_controller;

  // 初始化函数，创建 can socket
  void initCanSocket()
  {
    socketCan = socket(PF_CAN, SOCK_RAW, CAN_RAW);
    struct ifreq ifr;
    strcpy(ifr.ifr_name, can_name.c_str());
    RCLCPP_INFO(this->get_logger(), "CanMsgsNode init, can_name is: %s", can_name.c_str());
    ioctl(socketCan, SIOCGIFINDEX, &ifr); // 指定 can 设备
    // m_addr = {0};
    m_addr.can_family = AF_CAN;
    m_addr.can_ifindex = ifr.ifr_ifindex;
    bind(socketCan, (struct sockaddr *)&m_addr, sizeof(m_addr)); // 将套接字与 can 绑定

    // 接收底盘 can 报文反馈
    // pthread_create 返回值为 0 表示创建线程成功，否则创建失败
    if (pthread_create(&can_rcv_thread, NULL, thread_can_receive, (void *)this) == 0)
    {
      pthread_detach(can_rcv_thread); // success 创建成功
    }

    // 给底盘发送控制 can 报文数据

    initCanMsgData();
    // 创建计时器，定期调用 sendCanMsgTimerCallback 来发送 can 报文给底盘
    int send_frequency_ms = (1.0 / send_frequency) * 1000; // 转换为 ms
    timer_ = this->create_wall_timer(
        std::chrono::milliseconds(send_frequency_ms), std::bind(&CanMsgsNode::sendCanMsgTimerCallback, this));
  }

  void initCanMsgData()
  {
    // 需要初始化，否则会出现 std::out_of_range 的错误
    // 构造初始化 can 数据，全都初始化为默认值，但是其最终值取决于上层的 pacmod 传下来的 can topic 的值
    // 之所以需要初始化 periodic_frame_map，是因为 sendCanMsgTimerCallback 中调用了一些 id
    struct can_frame frame;
    frame.can_dlc = 8;

    frame.can_id = S12n01_Actuate_Cmd;
    periodic_frame_map[S12n01_Actuate_Cmd] = frame;

    frame.can_id = S12n01_Steer_Cmd;
    periodic_frame_map[S12n01_Steer_Cmd] = frame;

    frame.can_id = S12n01_Brake_Cmd;
    periodic_frame_map[S12n01_Brake_Cmd] = frame;

    frame.can_id = S12n01_Park_Cmd;
    periodic_frame_map[S12n01_Park_Cmd] = frame;

  }

  // 订阅 can_rx 话题，更新 canMsgMap
  void subCanTopicFromPacmod(const diapp_pacmod3_msgs_s12n01::msg::Frame &msg)
  {
    // 发送 can switch msg
    auto switch_flag_msg = std::make_shared<std_msgs::msg::Int32>();
    switch_flag_msg->data = can_switch_flag;
    pub_can_switch_flag_msg_->publish(*switch_flag_msg);

    if (can_switch_flag == 1)
    {
      struct can_frame frame;
      memset(&frame, 0, sizeof(frame));
      frame.can_id = msg.id;
      frame.can_dlc = msg.dlc;
      memcpy(frame.data, msg.data.begin(), sizeof(frame.data));
      periodic_frame_map[frame.can_id] = frame; // 接收 pacmod 的 can topic 后覆盖赋值给 periodic_frame_map
      // 读取其中的一些值，做一些处理
      switch (frame.can_id)
      {
      case S12n01_Actuate_Cmd:
      {
        // 读取进自驾模式指令
        s12n01_control_mode_cmd = frame.data[0] & 0x3;
        // 检测是否有档位切换
        if (s12n01_control_mode_cmd == 2) // 自驾模式指令下
        {
          // 如果检测到之前的档位请求和现在的档位请求不一致，则将 gear_cnt 置为 1
          if (previous_gear != frame.data[0] && gear_cnt == 0)
          {
            previous_gear = frame.data[0];
            gear_cnt = 1;
          }
        }
        else
        {
          frame.data[0] = 0;
        }
      }
      break;
      case S12n01_Park_Cmd:
      {
        curr_park_mode = frame.data[6];
        // 如果驻车工作模式要求发送人工介入回复，保持3帧
        if (true == park_recover_flag)
        {
          switch (curr_park_mode)
          {
            case 0x0:
            park_recover_flag = false;
            park_recover_cnt = 0;
            break;
            case 0x5:
            break;
            case 0x9:
            if (park_recover_cnt_threshold == park_recover_cnt)
            {
              park_recover_flag = false;
              park_recover_cnt = 0;
            }
            else
            {
              frame.data[6] = 0x5;  // 0x5不满3帧，继续发0x5
            }
            break;
            default:
            break;
          }
        }
        else
        {
          if (0x5 == curr_park_mode)
          {
            park_recover_flag = true;
            park_recover_cnt = 0;
          }
        }
      }
      break;
      default:
      break;
      }
    }
  }

  uint8_t calculateCheckSum(const struct can_frame &frame)
  {
    uint32_t sum = 0u;
    for (size_t i = 0u; i < 7; i++)
    {
      sum += frame.data[i];
    }
    sum += msg_cnt & 0x0F;
    uint32_t canID = frame.can_id;
    sum += (canID & 0xFF000000) >> 24;
    sum += (canID & 0x00FF0000) >> 16;
    sum += (canID & 0x0000FF00) >> 8;
    sum += canID & 0x000000FF;
    uint8_t checksum = ((sum >> 4) + sum) & 0x0F;

    return checksum;
  }

  // 更新消息计数器和校验码
  void updatemsg_cntAndCheckSum(struct can_frame &frame)
  {
    uint32_t sum = 0u;
    for (size_t i = 0u; i < 7; i++)
    {
      sum += frame.data[i];
    }
    sum += msg_cnt & 0x0F;
    sum += (frame.can_id & 0xFF000000) >> 24;
    sum += (frame.can_id & 0x00FF0000) >> 16;
    sum += (frame.can_id & 0x0000FF00) >> 8;
    sum += frame.can_id & 0x000000FF;
    sum = ((sum >> 4) + sum) & 0x0F;
    frame.data[7] = ((sum & 0x0F) << 4) | (msg_cnt & 0x0F);
  }

  void sendCanMsgToSocket(struct can_frame frame)
  {
    // sendto(socketCan, &frame, sizeof(frame), 0,
    //    (struct sockaddr *)&m_addr, sizeof(m_addr));
    frame.can_id = frame.can_id | CAN_EFF_FLAG;
    int ret = write(socketCan, &frame, sizeof(struct can_frame));
    if (ret != sizeof(frame) && ret != -1)
    {
      RCLCPP_ERROR(this->get_logger(), "sendCanMsgToSocket send failed: %d", ret);
    }
  }

  void sendCanMsgTimerCallback()
  {
    // 档位指令发送 gear_cnt_threshold 帧后置为 0（T018 协议）  TODO: S12n01挡位切换逻辑是否有5帧要求，需试车测试
    if (gear_cnt > 0 && gear_cnt <= gear_cnt_threshold)
    {
      gear_cnt++;
    }
    else
    {
      periodic_frame_map[S12n01_Actuate_Cmd].data[0] = 0;
      gear_cnt = 0;
    }

    // 驻车工作模式发送帧数计数
    if (true == park_recover_flag)
    {
      park_recover_cnt += 1;
      park_recover_cnt = std::min(park_recover_cnt_threshold, park_recover_cnt);
    }
    // RCLCPP_INFO(this->get_logger(), "du_test: t018_control_mode_cmd: %d, previous_gear: %d, cur_gear: %d, gear_cnt: %d",
    //             t018_control_mode_cmd, previous_gear, periodic_frame_map[T018_Act_Str_Cmd].data[0], gear_cnt);

    for (auto &frame_i : periodic_frame_map)
    {
      updatemsg_cntAndCheckSum(frame_i.second);
      sendCanMsgToSocket(frame_i.second);
    }

    if (++msg_cnt > 0xF)
    {
      msg_cnt = 0x0;
    }
  }

  /* rviz 交互函数 */
  // 构造 can 帧
  struct can_frame constructCanFrame(uint32_t can_id, uint8_t dlc, std::vector<uint8_t> data)
  {
    struct can_frame frame;
    frame.can_id = can_id;
    frame.can_dlc = dlc;
    for (int i = 0; i < dlc; ++i)
    {
      frame.data[i] = data[i];
    }
    return frame;
  }

  // 读取 txt can 数据并更新 periodic_frame_map
  void readTxtUpdatePeriodicFrameMap(std::string txt_file_name)
  {
    if (can_switch_flag == 1)
      can_switch_flag = -can_switch_flag;
    // 从 txt 中读取
    std::string file_path = ament_index_cpp::get_package_share_directory("diapp_s12n01_can_rx_tx") + txt_file_name;

    std::vector<CanMessageStruct> can_frames = get_can_data_from_file(file_path);
    for (const auto &frame_i : can_frames)
    {
      struct can_frame frame = constructCanFrame(frame_i.id, 8, frame_i.data);
      periodic_frame_map[frame_i.id] = frame;
    }
  }

  // 接收到 rviz 点击按钮后，读取文件并发送 can 报文
  void subRvizButtonFlagMsg(const std_msgs::msg::Int32::SharedPtr msg)
  {
    if (gear_cnt == 0)
      gear_cnt = 1;
    int button_flag = msg->data;
    RCLCPP_INFO(this->get_logger(), "du_test: receive button flag from rviz panel: %d", button_flag);
    // 1Enter Auto	| 2Exit Auto		| 3Recovery		| 4CanSwitch
    // 5Debug		| 6Handbrake On		| 7Handbrake Off| 8HazardLight
    if (button_flag == 1) // Enter Auto 进入自动驾驶模式 02，无手刹，无扭矩
    {
      readTxtUpdatePeriodicFrameMap("/config/EnterAuto.txt");
    }
    else if (button_flag == 2) // Exit Auto 退出自动驾驶模式
    {
      readTxtUpdatePeriodicFrameMap("/config/ExitAuto.txt");
    }
    else if (button_flag == 3) // Recovery 从 人工介入模式 03 恢复到 人工驾驶模式 01
    {
      readTxtUpdatePeriodicFrameMap("/config/Recovery.txt");
    }
    else if (button_flag == 4) // 切换指令是从 diapp 发送还是从 txt 文件中读取
    {
      can_switch_flag = -can_switch_flag;
    }
    else if (button_flag == 5) // Debug，读取 /config/DebugCanMsg.txt 数据发送
    {
      readTxtUpdatePeriodicFrameMap("/config/DebugCanMsg.txt");
    }
    else if (button_flag == 6) // 进入自动驾驶模式，有手刹，无扭矩
    {
      readTxtUpdatePeriodicFrameMap("/config/HandBrake.txt");
    }
    else if (button_flag == 7) // 进入自动驾驶模式，无手刹，无扭矩
    {
      readTxtUpdatePeriodicFrameMap("/config/EnterAuto.txt");
    }
    else if (button_flag == 8 && !hazard_controller.is_pressed()) // 双闪
    {
      RCLCPP_INFO(this->get_logger(), "du_test: button_flag: %d, press hazard once", button_flag);
      hazard_controller.pressed_once();
    }
  }

  // 将字符串 can 数据转换为 vector
  std::vector<uint8_t> convertHexStringToByteArray(const std::string &hexString)
  {
    std::istringstream iss(hexString);
    std::vector<uint8_t> byteArray;

    // 每两个字符表示一个十六进制数，因此需要循环除以二（每次读取两个字符）
    for (size_t i = 0; i < hexString.length(); i += 2)
    {
      uint32_t byte;
      iss >> std::hex >> byte;

      byteArray.push_back(static_cast<uint8_t>(byte));
    }

    return byteArray;
  }

  // 读取 txt 格式的 can id 和 can 数据
  std::vector<CanMessageStruct> get_can_data_from_file(const std::string &file_path)
  {
    std::regex pattern("\\[(.*?)\\]");
    std::vector<CanMessageStruct> can_frames;

    std::ifstream file(file_path);
    if (!file.is_open())
    {
      RCLCPP_INFO(this->get_logger(), "du_test: Failed to open file: %s", file_path.c_str());
      return can_frames;
    }
    // else
    // {
    //     RCLCPP_INFO(this->get_logger(), "du_test: Open file succeed: %s", file_path.c_str());
    // }

    std::string line;
    int line_count = 0;
    while (std::getline(file, line))
    {
      line_count++;
      std::smatch matches;

      // 如果该行第一个字符为 # 或回车，则视为注释跳过该行
      if (line[0] == '#' || line.empty())
      {
        // RCLCPP_INFO(this->get_logger(), "du_test: note line %d", line_count);
        continue;
      }

      // 匹配第一个 []
      if (std::regex_search(line, matches, pattern))
      {
        std::string can_id_str = matches[1].str();
        std::string can_data_str;

        // 将搜索位置移动到上一次匹配的结束位置后
        line = matches.suffix();
        // 匹配第二个 【】
        if (std::regex_search(line, matches, pattern))
          can_data_str = matches[1].str();

        // 格式转换
        uint32_t can_id = std::stoul(can_id_str, nullptr, 16);
        std::vector<uint8_t> can_data = convertHexStringToByteArray(can_data_str);

        // Create CAN message and add it to the vector
        CanMessageStruct can_msg;
        can_msg.id = can_id;
        can_msg.data = can_data;
        can_frames.push_back(can_msg);
      }
      else
      {
        RCLCPP_INFO(this->get_logger(), "Please check if the [can id] and [can msg] in file %s line %d", file_path.c_str(), line_count);
      }
    }

    file.close();
    return can_frames;
  }
};

int main(int argc, char *argv[])
{
  rclcpp::init(argc, argv);
  rclcpp::NodeOptions opt;
  auto node = std::make_shared<CanMsgsNode>(opt);
  rclcpp::spin(node);
  rclcpp::shutdown();
}
