
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#ifndef PACMOD_INTERFACE__PACMOD_INTERFACE_HPP_
#define PACMOD_INTERFACE__PACMOD_INTERFACE_HPP_

#include <rclcpp/rclcpp.hpp>
#include <diapp_api_utils/diapp_api_utils.hpp>
#include <vehicle_info_util/vehicle_info_util.hpp>
#include <geometry_msgs/msg/twist_with_covariance_stamped.hpp>
#include <diapp_control_msgs/msg/ackermann_control_command.hpp>
#include <diapp_vehicle_msgs/msg/control_mode_report.hpp>
#include <diapp_vehicle_msgs/msg/engage.hpp>
#include <diapp_vehicle_msgs/msg/gear_command.hpp>
#include <diapp_vehicle_msgs/msg/gear_report.hpp>
#include <diapp_vehicle_msgs/msg/hazard_lights_command.hpp>
#include <diapp_vehicle_msgs/msg/hazard_lights_report.hpp>
#include <diapp_vehicle_msgs/msg/steering_report.hpp>
#include <diapp_vehicle_msgs/msg/turn_indicators_command.hpp>
#include <diapp_vehicle_msgs/msg/turn_indicators_report.hpp>
#include <diapp_vehicle_msgs/msg/velocity_report.hpp>
#include <diapp_vehicle_msgs/srv/control_mode_command.hpp>
#include <diapp_vehicle_msgs/msg/operation_mode_state.hpp>

#include <diapp_api_msgs/msg/door_status.hpp>
#include <diapp_external_api_msgs/srv/set_door.hpp>
#include <diapp_vehicle_msgs/msg/actuation_command_stamped.hpp>
#include <diapp_vehicle_msgs/msg/actuation_status_stamped.hpp>
#include <diapp_vehicle_msgs/msg/steering_wheel_status_stamped.hpp>
#include <diapp_vehicle_msgs/msg/vehicle_emergency_stamped.hpp>

#include <diapp_pacmod3_msgs_s12n01/msg/s12n01_actuate_cmd.hpp>
#include <diapp_pacmod3_msgs_s12n01/msg/s12n01_steer_cmd.hpp>
#include <diapp_pacmod3_msgs_s12n01/msg/s12n01_brake_cmd.hpp>
#include <diapp_pacmod3_msgs_s12n01/msg/s12n01_park_cmd.hpp>

#include <diapp_pacmod3_msgs_s12n01/msg/s12n01_actuate_rpt.hpp>
#include <diapp_pacmod3_msgs_s12n01/msg/s12n01_steer_rpt.hpp>
#include <diapp_pacmod3_msgs_s12n01/msg/s12n01_speed_rpt.hpp>
#include <diapp_pacmod3_msgs_s12n01/msg/s12n01_accel_rpt.hpp>
#include <diapp_pacmod3_msgs_s12n01/msg/s12n01_brake_rpt.hpp>
#include <diapp_pacmod3_msgs_s12n01/msg/s12n01_xbr_rpt.hpp>
#include <diapp_pacmod3_msgs_s12n01/msg/s12n01_whl_spd_rpt.hpp>
#include <diapp_pacmod3_msgs_s12n01/msg/s12n01_park_rpt.hpp>
#include <diapp_pacmod3_msgs_s12n01/msg/s12n01_brk_prs_rpt.hpp>


#include <message_filters/subscriber.h>
#include <message_filters/sync_policies/approximate_time.h>
#include <message_filters/synchronizer.h>

#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <memory>
#include <optional>
#include <string>

#define STEER_RATE 2u
#define TEST_MODE true
#define ACCEL_PERIOD 1
#define BRAKE_PERIOD 20
#define GEARTEST_PERIOD 10
#define GEARTEST_PERIOD1 20
#define GEARTEST_PERIOD2 30

class PacmodInterface : public rclcpp::Node
{
public:
  using ActuationCommandStamped = diapp_vehicle_msgs::msg::ActuationCommandStamped;
  using ActuationStatusStamped = diapp_vehicle_msgs::msg::ActuationStatusStamped;
  using SteeringWheelStatusStamped = diapp_vehicle_msgs::msg::SteeringWheelStatusStamped;
  PacmodInterface();

private:
  //S12n01
  typedef message_filters::sync_policies::ApproximateTime<
      diapp_pacmod3_msgs_s12n01::msg::S12n01ActuateRpt,
      diapp_pacmod3_msgs_s12n01::msg::S12n01SteerRpt,
      diapp_pacmod3_msgs_s12n01::msg::S12n01WhlSpdRpt,
      diapp_pacmod3_msgs_s12n01::msg::S12n01AccelRpt,
      diapp_pacmod3_msgs_s12n01::msg::S12n01ParkRpt>
      S12n01PacmodFeedbacksSyncPolicy_50hz;

  /* subscribers */
  // From DiAPP
  rclcpp::Subscription<diapp_control_msgs::msg::AckermannControlCommand>::SharedPtr control_cmd_sub_;
  rclcpp::Subscription<diapp_vehicle_msgs::msg::GearCommand>::SharedPtr gear_cmd_sub_;
  rclcpp::Subscription<diapp_vehicle_msgs::msg::TurnIndicatorsCommand>::SharedPtr turn_indicators_cmd_sub_;
  rclcpp::Subscription<diapp_vehicle_msgs::msg::HazardLightsCommand>::SharedPtr hazard_lights_cmd_sub_;
  rclcpp::Subscription<diapp_vehicle_msgs::msg::VehicleEmergencyStamped>::SharedPtr emergency_sub_;
  rclcpp::Subscription<diapp_vehicle_msgs::msg::OperationModeState>::SharedPtr operation_mode_state_sub_;
  rclcpp::Subscription<ActuationCommandStamped>::SharedPtr actuation_cmd_sub_;

  // From Pacmod
  // S12N01
  std::unique_ptr<message_filters::Subscriber<diapp_pacmod3_msgs_s12n01::msg::S12n01ActuateRpt>> actuate_rpt_sub_;
  std::unique_ptr<message_filters::Subscriber<diapp_pacmod3_msgs_s12n01::msg::S12n01SteerRpt>> steer_rpt_sub_;
  std::unique_ptr<message_filters::Subscriber<diapp_pacmod3_msgs_s12n01::msg::S12n01WhlSpdRpt>> wheel_speed_rpt_sub_;
  std::unique_ptr<message_filters::Subscriber<diapp_pacmod3_msgs_s12n01::msg::S12n01AccelRpt>> accel_rpt_sub_;
  std::unique_ptr<message_filters::Subscriber<diapp_pacmod3_msgs_s12n01::msg::S12n01ParkRpt>> park_rpt_sub_;
  std::unique_ptr<message_filters::Subscriber<diapp_pacmod3_msgs_s12n01::msg::S12n01BrkPrsRpt>> brk_prs_rpt_sub_;
  std::unique_ptr<message_filters::Subscriber<diapp_pacmod3_msgs_s12n01::msg::S12n01XbrRpt>> xbr_rpt_sub_;
  rclcpp::Subscription<diapp_pacmod3_msgs_s12n01::msg::S12n01SpeedRpt>::SharedPtr speed_rpt_sub_;
  rclcpp::Subscription<diapp_pacmod3_msgs_s12n01::msg::S12n01BrakeRpt>::SharedPtr brake_rpt_sub_;


  std::unique_ptr<message_filters::Synchronizer<S12n01PacmodFeedbacksSyncPolicy_50hz>> pacmod_feedbacks_sync_s12n01_50hz_;

  /* publishers */
  // To Pacmod
  rclcpp::Publisher<diapp_pacmod3_msgs_s12n01::msg::S12n01ActuateCmd>::SharedPtr s12n01_actuate_cmd_pub_;
  rclcpp::Publisher<diapp_pacmod3_msgs_s12n01::msg::S12n01SteerCmd>::SharedPtr s12n01_steer_cmd_pub_;
  rclcpp::Publisher<diapp_pacmod3_msgs_s12n01::msg::S12n01BrakeCmd>::SharedPtr s12n01_brake_cmd_pub_;
  rclcpp::Publisher<diapp_pacmod3_msgs_s12n01::msg::S12n01ParkCmd>::SharedPtr s12n01_park_cmd_pub_;

  // To DiAPP
  rclcpp::Publisher<diapp_vehicle_msgs::msg::ControlModeReport>::SharedPtr control_mode_pub_;
  rclcpp::Publisher<diapp_vehicle_msgs::msg::VelocityReport>::SharedPtr vehicle_twist_pub_;
  rclcpp::Publisher<geometry_msgs::msg::TwistWithCovarianceStamped>::SharedPtr twist_with_covariance_pub_;
  rclcpp::Publisher<diapp_vehicle_msgs::msg::SteeringReport>::SharedPtr steering_status_pub_;
  rclcpp::Publisher<diapp_vehicle_msgs::msg::GearReport>::SharedPtr gear_status_pub_;
  rclcpp::Publisher<diapp_vehicle_msgs::msg::TurnIndicatorsReport>::SharedPtr turn_indicators_status_pub_;
  rclcpp::Publisher<diapp_vehicle_msgs::msg::HazardLightsReport>::SharedPtr hazard_lights_status_pub_;
  rclcpp::Publisher<ActuationStatusStamped>::SharedPtr actuation_status_pub_;
  rclcpp::Publisher<SteeringWheelStatusStamped>::SharedPtr steering_wheel_status_pub_;

  rclcpp::TimerBase::SharedPtr timer_;

  /* ros param */
  std::string base_frame_id_;
  int command_timeout_ms_; // vehicle_cmd timeout [ms]
  bool is_pacmod_rpt_received_ = false;
  bool is_pacmod_enabled_ = false;
  bool is_clear_override_needed_ = false;
  bool prev_override_ = false;
  double loop_rate_;          // [Hz]
  double tire_radius_;        // [m]
  double wheel_base_;         // [m]
  double steering_offset_;    // [rad] def: measured = truth + offset
  double vgr_coef_a_;         // variable gear ratio coeffs
  double vgr_coef_b_;         // variable gear ratio coeffs
  double vgr_coef_c_;         // variable gear ratio coeffs
  double accel_pedal_offset_; // offset of accel pedal value
  double brake_pedal_offset_; // offset of brake pedal value
  double speed_scale_factor_; // scale factor of speed

  double emergency_brake_;             // brake command when emergency [m/s^2]
  double max_throttle_;                // max throttle [0~1]
  double max_brake_;                   // max throttle [0~1]
  double max_steering_wheel_;          // max steering wheel angle [rad]
  double max_steering_wheel_rate_;     // [rad/s]
  double min_steering_wheel_rate_;     // [rad/s]
  double steering_wheel_rate_low_vel_; // [rad/s]
  double steering_wheel_rate_stopped_; // [rad/s]
  double low_vel_thresh_;              // [m/s]
  double steer_torque_threshold_;      // [N*m]
  float  steer_ratio_;                 // wheel-steer factor

  bool enable_steering_rate_control_; // use steering angle speed for command [rad/s]

  double hazard_thresh_time_;
  int hazard_recover_count_ = 0;
  const int hazard_recover_cmd_num_ = 5;

  int last_shift_ = 7;
  int last_level_ = 0;

  vehicle_info_util::VehicleInfo vehicle_info_;

  uint8_t prev_rviz_control_mode = diapp_vehicle_msgs::msg::OperationModeState::UNKNOWN;
  uint8_t control_mode_diff_count = 0;

  // Service
  diapp_api_utils::Service<diapp_external_api_msgs::srv::SetDoor>::SharedPtr srv_;
  rclcpp::Service<diapp_vehicle_msgs::srv::ControlModeCommand>::SharedPtr control_mode_server_;

  /* input values */
  ActuationCommandStamped::ConstSharedPtr actuation_cmd_ptr_;
  diapp_control_msgs::msg::AckermannControlCommand::ConstSharedPtr control_cmd_ptr_;
  diapp_vehicle_msgs::msg::TurnIndicatorsCommand::ConstSharedPtr turn_indicators_cmd_ptr_;
  diapp_vehicle_msgs::msg::HazardLightsCommand::ConstSharedPtr hazard_lights_cmd_ptr_;
  diapp_vehicle_msgs::msg::GearCommand::ConstSharedPtr gear_cmd_ptr_;
  diapp_vehicle_msgs::msg::OperationModeState::ConstSharedPtr rviz_control_mode;
  //S12n01
  diapp_pacmod3_msgs_s12n01::msg::S12n01ActuateRpt::ConstSharedPtr actuate_rpt_ptr_;
  diapp_pacmod3_msgs_s12n01::msg::S12n01SteerRpt::ConstSharedPtr steer_rpt_ptr_;
  diapp_pacmod3_msgs_s12n01::msg::S12n01WhlSpdRpt::ConstSharedPtr wheel_speed_rpt_ptr_;
  diapp_pacmod3_msgs_s12n01::msg::S12n01AccelRpt::ConstSharedPtr accel_rpt_ptr_;
  diapp_pacmod3_msgs_s12n01::msg::S12n01SpeedRpt::ConstSharedPtr speed_rpt_ptr_;
  diapp_pacmod3_msgs_s12n01::msg::S12n01BrakeRpt::ConstSharedPtr brake_rpt_ptr_;
  diapp_pacmod3_msgs_s12n01::msg::S12n01ParkRpt::ConstSharedPtr park_rpt_ptr_;
  diapp_pacmod3_msgs_s12n01::msg::S12n01BrkPrsRpt::ConstSharedPtr brk_prs_rpt_ptr_;

  bool engage_cmd_{false};
  bool is_emergency_{false};
  rclcpp::Time control_command_received_time_;
  rclcpp::Time actuation_command_received_time_;
  rclcpp::Time last_shift_inout_matched_time_;

  /* callbacks */
  void callbackActuationCmd(const ActuationCommandStamped::ConstSharedPtr msg);
  void callbackControlCmd(const diapp_control_msgs::msg::AckermannControlCommand::ConstSharedPtr msg);
  void callbackEmergencyCmd(const diapp_vehicle_msgs::msg::VehicleEmergencyStamped::ConstSharedPtr msg);
  void callbackGearCmd(const diapp_vehicle_msgs::msg::GearCommand::ConstSharedPtr msg);
  void callbackTurnIndicatorsCommand(const diapp_vehicle_msgs::msg::TurnIndicatorsCommand::ConstSharedPtr msg);
  void callbackHazardLightsCommand(const diapp_vehicle_msgs::msg::HazardLightsCommand::ConstSharedPtr msg);
  void callbackOperationModeState(const diapp_vehicle_msgs::msg::OperationModeState::ConstSharedPtr msg);
  //S12n01
  void callbackPacmodRptS12n01_50hz(
      const diapp_pacmod3_msgs_s12n01::msg::S12n01ActuateRpt::ConstSharedPtr actuate_rpt,
      const diapp_pacmod3_msgs_s12n01::msg::S12n01SteerRpt::ConstSharedPtr steer_rpt,
      const diapp_pacmod3_msgs_s12n01::msg::S12n01WhlSpdRpt::ConstSharedPtr wheel_speed_rpt,
      const diapp_pacmod3_msgs_s12n01::msg::S12n01AccelRpt::ConstSharedPtr accel_rpt,
      const diapp_pacmod3_msgs_s12n01::msg::S12n01ParkRpt::ConstSharedPtr park_rpt);
  void callbackPacmodRptS12n01_20hz(const diapp_pacmod3_msgs_s12n01::msg::S12n01SpeedRpt::ConstSharedPtr speed_rpt);
  void callbackPacmodRptS12n01_10hz(const diapp_pacmod3_msgs_s12n01::msg::S12n01BrakeRpt::ConstSharedPtr brake_rpt);

  /*  functions */
  void publishCommands();
  double calculateVariableGearRatio(const double vel, const double steer_wheel);
  uint16_t toPacmodShiftCmd(const diapp_vehicle_msgs::msg::GearCommand &gear_cmd);

  std::optional<int32_t> toAutowareGearStatusReport(const diapp_pacmod3_msgs_s12n01::msg::S12n01ActuateRpt &shift);

  void onControlModeRequest(
      const diapp_vehicle_msgs::srv::ControlModeCommand::Request::SharedPtr request,
      const diapp_vehicle_msgs::srv::ControlModeCommand::Response::SharedPtr response);
  float vehicle_speed_;
  bool park_recover_flag_{false};
};

#endif // PACMOD_INTERFACE__PACMOD_INTERFACE_HPP_

