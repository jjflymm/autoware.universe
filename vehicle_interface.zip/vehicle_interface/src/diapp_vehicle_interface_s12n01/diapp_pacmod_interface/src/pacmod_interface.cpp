// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//     http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include <pacmod_interface.hpp>

#include <algorithm>
#include <limits>
#include <memory>
#include <utility>

PacmodInterface::PacmodInterface()
    : Node("pacmod_interface"),
      vehicle_info_(vehicle_info_util::VehicleInfoUtil(*this).getVehicleInfo())
{
  /* setup parameters */
  base_frame_id_ = declare_parameter("base_frame_id", "base_link");
  command_timeout_ms_ = declare_parameter("command_timeout_ms", 1000);
  loop_rate_ = declare_parameter("loop_rate", 30.0);

  /* parameters for vehicle specifications */
  tire_radius_ = vehicle_info_.wheel_radius_m;
  wheel_base_ = vehicle_info_.wheel_base_m;

  steering_offset_ = declare_parameter("steering_offset", 0.0);
  enable_steering_rate_control_ = declare_parameter("enable_steering_rate_control", false);

  /* parameters for emergency stop */
  emergency_brake_ = declare_parameter("emergency_brake", 0.3);

  /* vehicle parameters */
  vgr_coef_a_ = declare_parameter("vgr_coef_a", 15.713);
  vgr_coef_b_ = declare_parameter("vgr_coef_b", 0.053);
  vgr_coef_c_ = declare_parameter("vgr_coef_c", 0.042);
  accel_pedal_offset_ = declare_parameter("accel_pedal_offset", 0.0);
  brake_pedal_offset_ = declare_parameter("brake_pedal_offset", 0.0);
  speed_scale_factor_ = declare_parameter("speed_scale_factor", 1.0);

  /* parameters for limitter */
  max_throttle_ = declare_parameter("max_throttle", 0.2);
  max_throttle_ = 0.6;
  max_brake_ = declare_parameter("max_brake", 0.8);
  max_steering_wheel_ = declare_parameter("max_steering_wheel", 2.7 * M_PI);
  max_steering_wheel_rate_ = declare_parameter("max_steering_wheel_rate", 6.6);
  min_steering_wheel_rate_ = declare_parameter("min_steering_wheel_rate", 0.5);
  steering_wheel_rate_low_vel_ = declare_parameter("steering_wheel_rate_low_vel", 5.0);
  steering_wheel_rate_stopped_ = declare_parameter("steering_wheel_rate_stopped", 5.0);
  low_vel_thresh_ = declare_parameter("low_vel_thresh", 1.389); // 5.0kmh
  steer_torque_threshold_ = declare_parameter("steer_torque_threshold", 0.1);
  steer_ratio_ = declare_parameter("steer_ratio", 23.5);

  /* parameters for turn signal recovery */
  hazard_thresh_time_ = declare_parameter("hazard_thresh_time", 0.20); // s
  /* initialize */
  using std::placeholders::_1;
  using std::placeholders::_2;

  /* subscribers */
  // From DiAPP
  control_cmd_sub_ = create_subscription<diapp_control_msgs::msg::AckermannControlCommand>(
      "/control/command/control_cmd", 1, std::bind(&PacmodInterface::callbackControlCmd, this, _1));
  gear_cmd_sub_ = create_subscription<diapp_vehicle_msgs::msg::GearCommand>(
      "/control/command/gear_cmd", 1, std::bind(&PacmodInterface::callbackGearCmd, this, _1));
  actuation_cmd_sub_ = create_subscription<ActuationCommandStamped>(
      "/control/command/actuation_cmd", 1, std::bind(&PacmodInterface::callbackActuationCmd, this, _1));
  emergency_sub_ = create_subscription<diapp_vehicle_msgs::msg::VehicleEmergencyStamped>(
      "/control/command/emergency_cmd", 1, std::bind(&PacmodInterface::callbackEmergencyCmd, this, _1));
  operation_mode_state_sub_ = create_subscription<diapp_vehicle_msgs::msg::OperationModeState>(
      "/api/operation_mode/state", 1, std::bind(&PacmodInterface::callbackOperationModeState, this, _1));

  // From pacmod3
  //S12n01
  actuate_rpt_sub_ = std::make_unique<message_filters::Subscriber<diapp_pacmod3_msgs_s12n01::msg::S12n01ActuateRpt>>(
      this, "/pacmod/s12n01_actuate_rpt");
  steer_rpt_sub_ = std::make_unique<message_filters::Subscriber<diapp_pacmod3_msgs_s12n01::msg::S12n01SteerRpt>>(
      this, "/pacmod/s12n01_steer_rpt");
  wheel_speed_rpt_sub_ = std::make_unique<message_filters::Subscriber<diapp_pacmod3_msgs_s12n01::msg::S12n01WhlSpdRpt>>(
      this, "/pacmod/s12n01_wheel_speed_rpt");
  accel_rpt_sub_ = std::make_unique<message_filters::Subscriber<diapp_pacmod3_msgs_s12n01::msg::S12n01AccelRpt>>(
      this, "/pacmod/s12n01_accel_rpt");
  xbr_rpt_sub_ = std::make_unique<message_filters::Subscriber<diapp_pacmod3_msgs_s12n01::msg::S12n01XbrRpt>>(
      this, "/pacmod/s12n01_xbr_rpt");
  park_rpt_sub_ = std::make_unique<message_filters::Subscriber<diapp_pacmod3_msgs_s12n01::msg::S12n01ParkRpt>>(
      this, "/pacmod/s12n01_park_rpt");
  brk_prs_rpt_sub_ = std::make_unique<message_filters::Subscriber<diapp_pacmod3_msgs_s12n01::msg::S12n01BrkPrsRpt>>(
      this, "/pacmod/s12n01_brk_prs_rpt");
  speed_rpt_sub_ = create_subscription<diapp_pacmod3_msgs_s12n01::msg::S12n01SpeedRpt>(
      "/pacmod/s12n01_speed_rpt", 1, std::bind(&PacmodInterface::callbackPacmodRptS12n01_20hz, this, _1));
  brake_rpt_sub_ = create_subscription<diapp_pacmod3_msgs_s12n01::msg::S12n01BrakeRpt>(
      "/pacmod/s12n01_brake_rpt",1,std::bind(&PacmodInterface::callbackPacmodRptS12n01_10hz, this, _1));


  /* publisher */
  // S12n01
  s12n01_actuate_cmd_pub_ = create_publisher<diapp_pacmod3_msgs_s12n01::msg::S12n01ActuateCmd>(
      "/pacmod_interface/s12n01_actuate_cmd", rclcpp::QoS{1});
  s12n01_steer_cmd_pub_ = create_publisher<diapp_pacmod3_msgs_s12n01::msg::S12n01SteerCmd>(
      "/pacmod_interface/s12n01_steer_cmd", rclcpp::QoS{1});
  s12n01_brake_cmd_pub_ = create_publisher<diapp_pacmod3_msgs_s12n01::msg::S12n01BrakeCmd>(
      "/pacmod_interface/s12n01_brake_cmd", rclcpp::QoS{1});
  s12n01_park_cmd_pub_ = create_publisher<diapp_pacmod3_msgs_s12n01::msg::S12n01ParkCmd>(
      "/pacmod_interface/s12n01_park_cmd", rclcpp::QoS{1});

  // To DiAPP
  control_mode_pub_ = create_publisher<diapp_vehicle_msgs::msg::ControlModeReport>(
      "/vehicle/status/control_mode", rclcpp::QoS{1});
  vehicle_twist_pub_ = create_publisher<diapp_vehicle_msgs::msg::VelocityReport>(
      "/vehicle/status/velocity_status", rclcpp::QoS{1});
  twist_with_covariance_pub_ = create_publisher<geometry_msgs::msg::TwistWithCovarianceStamped>(
      "/sensing/vehicle_velocity_converter/twist_with_covariance", rclcpp::QoS{1});
  steering_status_pub_ = create_publisher<diapp_vehicle_msgs::msg::SteeringReport>(
      "/vehicle/status/steering_status", rclcpp::QoS{1});
  gear_status_pub_ = create_publisher<diapp_vehicle_msgs::msg::GearReport>(
      "/vehicle/status/gear_status", rclcpp::QoS{1});
  actuation_status_pub_ = create_publisher<ActuationStatusStamped>(
      "/vehicle/status/actuation_status", 1);
  steering_wheel_status_pub_ = create_publisher<SteeringWheelStatusStamped>(
      "/vehicle/status/steering_wheel_status", 1);

  /* service */
  //  From Pacmod
  diapp_api_utils::ServiceProxyNodeInterface proxy(this);
  control_mode_server_ = create_service<diapp_vehicle_msgs::srv::ControlModeCommand>(
      "/control/control_mode_request", std::bind(&PacmodInterface::onControlModeRequest, this, _1, _2));

  pacmod_feedbacks_sync_s12n01_50hz_ = std::make_unique<message_filters::Synchronizer<S12n01PacmodFeedbacksSyncPolicy_50hz>>(
      S12n01PacmodFeedbacksSyncPolicy_50hz(10),
      *actuate_rpt_sub_, *steer_rpt_sub_, *wheel_speed_rpt_sub_, *accel_rpt_sub_, *park_rpt_sub_);
  pacmod_feedbacks_sync_s12n01_50hz_->registerCallback(std::bind(
      &PacmodInterface::callbackPacmodRptS12n01_50hz,
      this, std::placeholders::_1, std::placeholders::_2, std::placeholders::_3, std::placeholders::_4, std::placeholders::_5));

  // Timer，定时器发送指令
  const auto period_ns = rclcpp::Rate(loop_rate_).period();
  timer_ = rclcpp::create_timer(
      this, get_clock(), period_ns, std::bind(&PacmodInterface::publishCommands, this));
}

void PacmodInterface::callbackActuationCmd(const ActuationCommandStamped::ConstSharedPtr msg)
{
  actuation_command_received_time_ = this->now();
  actuation_cmd_ptr_ = msg;
}

void PacmodInterface::callbackEmergencyCmd(
    const diapp_vehicle_msgs::msg::VehicleEmergencyStamped::ConstSharedPtr msg)
{
  is_emergency_ = msg->emergency;
}

void PacmodInterface::callbackControlCmd(
    const diapp_control_msgs::msg::AckermannControlCommand::ConstSharedPtr msg)
{
  control_command_received_time_ = this->now();
  control_cmd_ptr_ = msg;
}

void PacmodInterface::callbackGearCmd(
    const diapp_vehicle_msgs::msg::GearCommand::ConstSharedPtr msg)
{
  gear_cmd_ptr_ = msg;
}

void PacmodInterface::onControlModeRequest(
    const diapp_vehicle_msgs::srv::ControlModeCommand::Request::SharedPtr request,
    const diapp_vehicle_msgs::srv::ControlModeCommand::Response::SharedPtr response)
{
  if (request->mode == diapp_vehicle_msgs::srv::ControlModeCommand::Request::AUTONOMOUS)
  {
    engage_cmd_ = true;
    is_clear_override_needed_ = true;
    response->success = true;
    return;
  }

  if (request->mode == diapp_vehicle_msgs::srv::ControlModeCommand::Request::MANUAL)
  {
    engage_cmd_ = false;
    is_clear_override_needed_ = true;
    response->success = true;
    return;
  }

  RCLCPP_ERROR(get_logger(), "unsupported control_mode!!");
  response->success = false;
  return;
}

void PacmodInterface::callbackOperationModeState(
    const diapp_vehicle_msgs::msg::OperationModeState::ConstSharedPtr msg)
{
  rviz_control_mode = msg;
  return;
}

// S12N01

void PacmodInterface::callbackPacmodRptS12n01_50hz(
    const diapp_pacmod3_msgs_s12n01::msg::S12n01ActuateRpt::ConstSharedPtr actuate_rpt,
    const diapp_pacmod3_msgs_s12n01::msg::S12n01SteerRpt::ConstSharedPtr steer_rpt,
    const diapp_pacmod3_msgs_s12n01::msg::S12n01WhlSpdRpt::ConstSharedPtr wheel_speed_rpt,
    const diapp_pacmod3_msgs_s12n01::msg::S12n01AccelRpt::ConstSharedPtr accel_rpt,
    const diapp_pacmod3_msgs_s12n01::msg::S12n01ParkRpt::ConstSharedPtr park_rpt)
{
  actuate_rpt_ptr_ = actuate_rpt;
  steer_rpt_ptr_ = steer_rpt;
  wheel_speed_rpt_ptr_ = wheel_speed_rpt;
  accel_rpt_ptr_ = accel_rpt;
  park_rpt_ptr_ = park_rpt;

  std_msgs::msg::Header header;
  header.frame_id = base_frame_id_;
  header.stamp = get_clock()->now();

  //control mode
  diapp_vehicle_msgs::msg::ControlModeReport control_mode_msg;
  control_mode_msg.stamp = header.stamp;
  if (actuate_rpt_ptr_->ctrl_mode == diapp_pacmod3_msgs_s12n01::msg::S12n01ActuateRpt::CTRL_MODE_AUTO)
  {
    control_mode_msg.mode = diapp_vehicle_msgs::msg::ControlModeReport::AUTONOMOUS; // mode: 1
  }
  else if(actuate_rpt_ptr_->ctrl_mode == diapp_pacmod3_msgs_s12n01::msg::S12n01ActuateRpt::CTRL_MODE_MAN)
  {
    control_mode_msg.mode = diapp_vehicle_msgs::msg::ControlModeReport::MANUAL; // mode: 4
  }
  else // diapp_pacmod3_msgs_s12n01::msg::S12n01ActuateRpt::CTRL_MODE_FAULT
  {
    control_mode_msg.mode = diapp_vehicle_msgs::msg::ControlModeReport::NOT_READY; // mode: 6
  }
  control_mode_pub_->publish(control_mode_msg);

  //gear
  const auto curr_shift = toAutowareGearStatusReport(*actuate_rpt_ptr_);
  if (curr_shift)
  {
    last_shift_ = *curr_shift;
  }
  {
    diapp_vehicle_msgs::msg::GearReport gear_report_msg;
    gear_report_msg.stamp = header.stamp;
    gear_report_msg.report = last_shift_;
    gear_status_pub_->publish(gear_report_msg);
  }

  //steer
  const double current_steer_wheel = steer_rpt_ptr_->steer_angle;
  const double current_steer = current_steer_wheel / 23.5; // todo zts 需确认美洲校车方向盘转角与车轮转角间的关系
  {
    diapp_vehicle_msgs::msg::SteeringReport steer_msg;
    steer_msg.stamp = header.stamp;
    steer_msg.steering_tire_angle = -current_steer; // autoware坐标系与车辆底盘坐标系相反
    steering_status_pub_->publish(steer_msg);
  }

  /* publish S12N01 actual control status */ //actual torque
  {
    ActuationStatusStamped actuation_status;
    actuation_status.header = header;
    actuation_status.status.accel_status = actuate_rpt_ptr_->actual_torque;
    // actuation_status.status.brake_status = brake_rpt_ptr_->output;
    //actuation_status.status.steer_status = -current_steer;
    actuation_status_pub_->publish(actuation_status);
  }
}

void PacmodInterface::callbackPacmodRptS12n01_20hz(
    const diapp_pacmod3_msgs_s12n01::msg::S12n01SpeedRpt::ConstSharedPtr speed_rpt)
{
  speed_rpt_ptr_ = speed_rpt;

  std_msgs::msg::Header header;
  header.frame_id = base_frame_id_;
  header.stamp = get_clock()->now();

  //speed
  const double current_velocity =
    (last_shift_ == diapp_vehicle_msgs::msg::GearReport::REVERSE)
        ? (-1.0 * speed_rpt->vehicle_speed) : speed_rpt->vehicle_speed;
  const double current_steer = (steer_rpt_ptr_->steer_angle) / 23.5; // todo zts 需确认美洲校车方向盘转角与车轮转角间的关系

  /* publish vehicle status twist */
  diapp_vehicle_msgs::msg::VelocityReport twist;
  twist.header = header;
  twist.longitudinal_velocity = current_velocity;                                // [m/s]
  twist.heading_rate = current_velocity * std::tan(current_steer) / wheel_base_; // [rad/s]

  geometry_msgs::msg::TwistWithCovarianceStamped twist_with_covariance_msg;
  twist_with_covariance_msg.header = twist.header;
  twist_with_covariance_msg.twist.twist.linear.x = twist.longitudinal_velocity;
  twist_with_covariance_msg.twist.twist.linear.y = twist.lateral_velocity;
  twist_with_covariance_msg.twist.twist.angular.z = twist.heading_rate;
  twist_with_covariance_msg.twist.covariance[0 + 0 * 6] = 0.04;
  twist_with_covariance_msg.twist.covariance[1 + 1 * 6] = 10000.0;
  twist_with_covariance_msg.twist.covariance[2 + 2 * 6] = 10000.0;
  twist_with_covariance_msg.twist.covariance[3 + 3 * 6] = 10000.0;
  twist_with_covariance_msg.twist.covariance[4 + 4 * 6] = 10000.0;
  twist_with_covariance_msg.twist.covariance[5 + 5 * 6] = 0.01;
  twist_with_covariance_pub_->publish(twist_with_covariance_msg);
  vehicle_twist_pub_->publish(twist);
}

void PacmodInterface::callbackPacmodRptS12n01_10hz(
    const diapp_pacmod3_msgs_s12n01::msg::S12n01BrakeRpt::ConstSharedPtr brake_rpt)
{
  brake_rpt_ptr_ = brake_rpt;
  std_msgs::msg::Header header;
  header.frame_id = base_frame_id_;
  header.stamp = get_clock()->now();
}

void PacmodInterface::publishCommands()
{
  using diapp_vehicle_msgs::msg::OperationModeState;
  using diapp_pacmod3_msgs_s12n01::msg::S12n01ActuateCmd;
  using diapp_pacmod3_msgs_s12n01::msg::S12n01SteerCmd;
  using diapp_pacmod3_msgs_s12n01::msg::S12n01BrakeCmd;
  using diapp_pacmod3_msgs_s12n01::msg::S12n01ParkCmd;
  using diapp_pacmod3_msgs_s12n01::msg::S12n01ActuateRpt;
  using diapp_pacmod3_msgs_s12n01::msg::S12n01ParkRpt;
  using diapp_pacmod3_msgs_s12n01::msg::S12n01SteerRpt;
  using diapp_pacmod3_msgs_s12n01::msg::S12n01BrakeRpt;

  /* guard */
  if (!actuation_cmd_ptr_ || !control_cmd_ptr_ || !is_pacmod_rpt_received_ || !gear_cmd_ptr_ || !rviz_control_mode)
  {
    return;
  }

  const rclcpp::Time current_time = get_clock()->now();

  double desired_throttle = actuation_cmd_ptr_->actuation.accel_cmd + accel_pedal_offset_;
  double desired_brake = actuation_cmd_ptr_->actuation.brake_cmd + brake_pedal_offset_;
  uint8_t desired_control_mode = 0;
  uint8_t desired_epb_mode = 0;

  /* check emergency and timeout */
  const double control_cmd_delta_time_ms =
      (current_time - control_command_received_time_).seconds() * 1000.0;
  const double actuation_cmd_delta_time_ms =
      (current_time - actuation_command_received_time_).seconds() * 1000.0;
  bool timeouted = false;
  const int t_out = command_timeout_ms_;
  if (t_out >= 0 && (control_cmd_delta_time_ms > t_out || actuation_cmd_delta_time_ms > t_out))
  {
    timeouted = true;
  }
  if (is_emergency_ || timeouted)
  {
    RCLCPP_ERROR(get_logger(), "Emergency Stopping, emergency = %d, timeouted = %d", is_emergency_, timeouted);
    desired_throttle = 0.0;
    desired_brake = emergency_brake_;
  }
  // 判断是否为倒挡
  const double current_velocity =
      (S12n01ActuateRpt::GEAR_REVERSE_S12N01 == actuate_rpt_ptr_->gear_status)
          ? (-1.0 * speed_rpt_ptr_->vehicle_speed)
          : speed_rpt_ptr_->vehicle_speed;

  vehicle_speed_ = current_velocity;
  const double current_steer_wheel = steer_rpt_ptr_->steer_angle;

  /* calculate desired steering wheel */
  double adaptive_gear_ratio = calculateVariableGearRatio(current_velocity, current_steer_wheel);
  double desired_steer_wheel =
      (control_cmd_ptr_->lateral.steering_tire_angle - steering_offset_) * adaptive_gear_ratio;
  desired_steer_wheel =
      std::min(std::max(desired_steer_wheel, -max_steering_wheel_), max_steering_wheel_);

  /* check clear flag */
  // bool clear_override = false;
  if (is_pacmod_enabled_ == true)
  {
    is_clear_override_needed_ = false;
  }

  /* check  gear_status change */
  // const double brake_for_shift_trans = 0.7;
  uint16_t desired_shift = toPacmodShiftCmd(*gear_cmd_ptr_);
  uint8_t desired_epb = 0; // 拉手刹指令

  // 拉手刹指令
  float current_velocity_tmp = abs(current_velocity * 3.6);
  bool epb_on_flag = false;
  epb_on_flag += (S12n01ActuateCmd::SHIFT_PARK_S12N01 == desired_shift);
  epb_on_flag += (S12n01ActuateCmd::SHIFT_NEUTRAL_S12N01 == desired_shift);
  epb_on_flag = epb_on_flag && (current_velocity_tmp < 5);

  float desired_steer_angle = std::min(std::max(-680.0, actuation_cmd_ptr_->actuation.steer_cmd * 180 / M_PI * 23.5), 680.0);
  // float desired_velocity = std::min(std::max(0.0, control_cmd_ptr_->longitudinal.speed * 3.6), 69.0);
  float desired_steer_rate = 0;
  uint8_t desired_steer_mode = 0;

  desired_steer_rate =
      std::abs(control_cmd_ptr_->lateral.steering_tire_rotation_rate * adaptive_gear_ratio);
  desired_steer_rate = std::min(std::max(0.0, desired_steer_rate * 180 / M_PI), 255.0);
  if (S12n01ActuateCmd::SHIFT_REVERSE_S12N01 == desired_shift)
  {
    desired_throttle = (desired_throttle > 0) ? -desired_throttle : desired_throttle;
  }

  /* 延迟退自驾：（1）拉手刹（2）将发给底盘的状态清零，包括清除制动指令 */
  /* judge prev_rviz_control_mode: AUTONOMOUS, STOP, LOCAL, REMOTE */
  if (rviz_control_mode->mode != prev_rviz_control_mode)
  {
    control_mode_diff_count++;
  }
  if (control_mode_diff_count > 50) // TODO:zhang.tiesheng@byd.com 后期改为时间长度
  {
    prev_rviz_control_mode = rviz_control_mode->mode;
    control_mode_diff_count = 0;
  }
  bool control_mode_delay_flag = true; // 延迟退自驾 flag
  // 之前是 AUTO，现在不是 AUTO，也就是到达终点退出 AUTO 后
  control_mode_delay_flag = control_mode_delay_flag && (prev_rviz_control_mode == OperationModeState::AUTONOMOUS);
  control_mode_delay_flag = control_mode_delay_flag && (rviz_control_mode->mode != OperationModeState::AUTONOMOUS);
  // 条件 1：AUTO 状态为 AUTONOMOUS || 条件 2: AUTO 状态为 LOCAL || 条件 3：延迟退自驾
  if (rviz_control_mode->mode == OperationModeState::AUTONOMOUS || rviz_control_mode->mode == OperationModeState::LOCAL || control_mode_delay_flag)
  {
    // 给底盘发进入自动驾驶的指令
    desired_control_mode = S12n01ActuateCmd::CTRL_MODE_AUTO;
  }
  else
  {
    desired_control_mode = S12n01ActuateCmd::CTRL_MODE_MAN;
  }

  desired_epb_mode = (S12n01ActuateCmd::CTRL_MODE_AUTO == desired_control_mode) ?
    S12n01ParkCmd::EPB_MODE_AUTO : S12n01ParkCmd::EPB_MODE_MAN;
  /* 从人工驾驶恢复到自动驾驶模式时需先发3帧EPB_MODE_RECOVER */
  /* 判断是否发送人工介入恢复 */
  bool nRecover = false;
  nRecover = nRecover || (S12n01SteerRpt::CTRL_MODE_RECOVER == steer_rpt_ptr_-> control_status);
  nRecover = nRecover || (S12n01ParkRpt::EPB_RECOVER == park_rpt_ptr_-> epb_work_status);
  nRecover = nRecover && (S12n01BrakeRpt::BRAKE_OFF == brake_rpt_ptr_->brake_pedal_flag);
  nRecover = nRecover && (S12n01SteerRpt::STEER_TORQUE_STANDARD > steer_rpt_ptr_->steer_torque);
  if (nRecover)
  {
    desired_epb_mode = S12n01ParkCmd::EPB_MODE_RECOVER;
    park_recover_flag_ = true;
  }
  else
  {
    park_recover_flag_ = false;
  }

  /* 新增转向控制报文工作模式 */
  if (S12n01ParkCmd::EPB_MODE_AUTO == desired_epb_mode)
  {
    desired_steer_mode = S12n01SteerCmd::CTRL_MODE_AUTO;
  }
  if (S12n01ParkCmd::EPB_MODE_MAN == desired_epb_mode)
  {
    desired_steer_mode = S12n01SteerCmd::CTRL_MODE_MANUAL;
  }
  if (S12n01ParkCmd::EPB_MODE_RECOVER == desired_epb_mode)
  {
    desired_steer_mode = S12n01SteerCmd::CTRL_MODE_RECOVER;
  }

  // 非自动驾驶模式下不发制动，这个可能会需要延迟退自驾 /* cancel the emergency brake for now */
  if (actuation_cmd_ptr_->actuation.brake_cmd <= 1e-7 ||
    actuate_rpt_ptr_->ctrl_mode != diapp_pacmod3_msgs_s12n01::msg::S12n01ActuateRpt::CTRL_MODE_AUTO)
  {
    desired_brake = S12n01BrakeCmd::NO_XBR_REQUEST; // 制动的默认值为 65535
  }
  else
  {
    desired_brake = -desired_brake;
  }

  if (epb_on_flag)
  {
    desired_epb = 251;
    desired_shift = S12n01ActuateCmd::SHIFT_NEUTRAL_S12N01;
  }

  /* publish s12n01_actuate_cmd */
  {
    diapp_pacmod3_msgs_s12n01::msg::S12n01ActuateCmd s12n01_actuate_cmd;
    s12n01_actuate_cmd.header.frame_id = base_frame_id_;
    s12n01_actuate_cmd.header.stamp = current_time;
    s12n01_actuate_cmd.ctrl_mode = desired_control_mode;
    s12n01_actuate_cmd.shift_des = desired_shift;
    s12n01_actuate_cmd.torque = round(desired_throttle); // 扭矩，取整
    s12n01_actuate_cmd_pub_->publish(s12n01_actuate_cmd);
  }

  /* publish s12n01_steer_cmd */
  {
    diapp_pacmod3_msgs_s12n01::msg::S12n01SteerCmd s12n01_steer_cmd;
    s12n01_steer_cmd.header.frame_id = base_frame_id_;
    s12n01_steer_cmd.header.stamp = current_time;
    s12n01_steer_cmd.steer_angle = -desired_steer_angle;
    s12n01_steer_cmd.steer_rate = desired_steer_rate;
    s12n01_steer_cmd.steer_mode = desired_steer_mode;
    s12n01_steer_cmd_pub_->publish(s12n01_steer_cmd);
  }

  /* publish s12n01_brake_cmd */
  {
    diapp_pacmod3_msgs_s12n01::msg::S12n01BrakeCmd s12n01_brake_cmd;
    s12n01_brake_cmd.header.frame_id = base_frame_id_;
    s12n01_brake_cmd.header.stamp = current_time;
    s12n01_brake_cmd.ex_acc_rqst = desired_brake;
    s12n01_brake_cmd.cont_brk_mode = ((desired_brake == S12n01BrakeCmd::NO_XBR_REQUEST) ? S12n01BrakeCmd::CONT_BRAKE_FORBIDDEN : S12n01BrakeCmd::CONT_BRAKE_ALLOWED);
    s12n01_brake_cmd.xbr_priority = ((desired_brake == S12n01BrakeCmd::NO_XBR_REQUEST) ? S12n01BrakeCmd::XBR_PRIO_LOW : S12n01BrakeCmd::XBR_PRIO_HIGHEST);
    s12n01_brake_cmd.xbr_mode = ((desired_brake == S12n01BrakeCmd::NO_XBR_REQUEST) ? S12n01BrakeCmd::XBR_MODE_SURPASS_FORBIDDEN : S12n01BrakeCmd::XBR_MODE_ACC_CTRL_MAXIMUM);
    s12n01_brake_cmd_pub_->publish(s12n01_brake_cmd);
  }

  /* publish s12n01_park_cmd */
  {
    diapp_pacmod3_msgs_s12n01::msg::S12n01ParkCmd s12n01_park_cmd;
    s12n01_park_cmd.header.frame_id = base_frame_id_;
    s12n01_park_cmd.header.stamp = current_time;
    s12n01_park_cmd.epb_pct = desired_epb;
    s12n01_park_cmd.epb_mode = desired_epb_mode;
    s12n01_park_cmd_pub_->publish(s12n01_park_cmd);
  }
}

// double PacmodInterface::calculateVariableGearRatio(const double vel, const double steer_wheel)
double PacmodInterface::calculateVariableGearRatio(const double, const double)
{
  // TODO: S12N01转向角转换:无转换系数，需进行标定
  return steer_ratio_;
}

uint16_t PacmodInterface::toPacmodShiftCmd(
    const diapp_vehicle_msgs::msg::GearCommand &gear_cmd)
{
  using diapp_pacmod3_msgs_s12n01::msg::S12n01ActuateCmd;

  if (gear_cmd.command == diapp_vehicle_msgs::msg::GearCommand::PARK)
  {
    return S12n01ActuateCmd::SHIFT_PARK_S12N01;
  }
  if (gear_cmd.command == diapp_vehicle_msgs::msg::GearCommand::REVERSE)
  {
    return S12n01ActuateCmd::SHIFT_REVERSE_S12N01;
  }
  if (gear_cmd.command == diapp_vehicle_msgs::msg::GearCommand::DRIVE)
  {
    return S12n01ActuateCmd::SHIFT_DRIVE_S12N01;
  }
  if (gear_cmd.command == diapp_vehicle_msgs::msg::GearCommand::LOW)
  {
    return S12n01ActuateCmd::SHIFT_NEUTRAL_S12N01;
  }
  return S12n01ActuateCmd::SHIFT_NONE_S12N01;
}

std::optional<int32_t> PacmodInterface::toAutowareGearStatusReport(
    const diapp_pacmod3_msgs_s12n01::msg::S12n01ActuateRpt &actuate_rpt_ptr_)
{
  auto gear_status = actuate_rpt_ptr_.gear_status;
  using diapp_pacmod3_msgs_s12n01::msg::S12n01ActuateRpt;
  using diapp_pacmod3_msgs_s12n01::msg::S12n01ParkRpt;
  using diapp_vehicle_msgs::msg::GearReport;

  // if ( gear_status == T018ActStrRpt::GEAR_PARK_T018)
  // S12N01 无 P 档，所以 N 档 + 拉上了手刹 视为 P 档
  if (gear_status == S12n01ActuateRpt::GEAR_NEUTRAL_S12N01 && park_rpt_ptr_->epb_status == S12n01ParkRpt::EPB_ON)
  {
    last_level_ = gear_status;
    return GearReport::PARK;
  }
  if (gear_status == S12n01ActuateRpt::GEAR_NEUTRAL_S12N01)
  {
    last_level_ = gear_status;
    return GearReport::LOW;
  }
  if (gear_status == S12n01ActuateRpt::GEAR_DRIVE_S12N01)
  {
    last_level_ = gear_status;
    return GearReport::DRIVE;
  }
  if (gear_status == S12n01ActuateRpt::GEAR_REVERSE_S12N01)
  {
    last_level_ = gear_status;
    return GearReport::REVERSE;
  }
  if (gear_status == S12n01ActuateRpt::GEAR_NONE_S12N01)
  {
    last_level_ = 0;
    return GearReport::NONE;
  }
  return GearReport::NONE;
}